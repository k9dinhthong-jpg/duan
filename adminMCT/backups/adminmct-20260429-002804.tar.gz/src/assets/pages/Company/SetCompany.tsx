import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import "./SetCompany.css";

type CompanyInfo = {
  id: number;
  short_name: string;
  full_name: string;
  slogan: string;
  tax_code: string;
  established_year: number;
  phone: string;
  hotline: string;
  email: string;
  website: string;
  address: string;
  map_address: string;
  google_map_embed: string;
  facebook: string;
  zalo: string;
  telegram: string;
  tiktok: string;
  instagram: string;
  youtube: string;
  wechat: string;
  logo_url: string;
  intro_image: string;
  favicon_url: string;
  meta_title: string;
  meta_description: string;
  meta_keywords: string;
  working_hours: string;
  is_active: 0 | 1;
  created_at: string;
  updated_at: string;
  custom_fields: CustomField[];
};

type CustomField = {
  id: string;
  key: string;
  label: string;
  value: string;
};

const COMPANY_STORAGE_KEY = "adminmct:company-info";

const defaultCompanyInfo: CompanyInfo = {
  id: 1,
  short_name: "MÁY CÔNG TRÌNH NHẬP KHẨU",
  full_name: "Công Ty Xuất Nhập Khẩu Máy Công Trình",
  slogan: "Máy Công Trình Chất Lượng Cao",
  tax_code: "Đang cập nhật",
  established_year: 2020,
  phone: "0966121686",
  hotline: "0966121686",
  email: "k9dinhthong@gmail.com",
  website: "https://maycongtrinhnhapkhau.com.vn",
  address: "Số 168 - Khu 4 - Xã Tế Lỗ",
  map_address: "https://www.google.com/maps",
  google_map_embed: "",
  facebook: "https://www.facebook.com/",
  zalo: "https://zalo.me/0966121686",
  telegram: "https://t.me/sugar88_vr",
  tiktok: "https://www.tiktok.com/",
  instagram: "#",
  youtube: "#",
  wechat: "https://ehsccjufbaehvfo",
  logo_url: "/img/Logo/Logo.png",
  intro_image: "/img/IntroCompany/Company.png",
  favicon_url: "/img/Logo/Favicon.png",
  meta_title: "KOBELCO - KOMATSU - HITACHI",
  meta_description:
    "Chuyên mua bán máy công trình nhập khẩu, máy xúc, máy đào, máy ủi, phụ tùng và dịch vụ liên quan.",
  meta_keywords:
    "máy công trình, máy xúc, máy đào, kobelco, komatsu, hitachi, máy công trình nhập khẩu",
  working_hours: "Thứ 2 - Chủ nhật: 08:00 - 18:00",
  is_active: 1,
  created_at: "2026-04-27 14:37:16",
  updated_at: "2026-04-28 10:58:03",
  custom_fields: [],
};

function loadCompanyFromDatabase(): CompanyInfo {
  const raw = localStorage.getItem(COMPANY_STORAGE_KEY);
  if (!raw) {
    return defaultCompanyInfo;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<CompanyInfo>;
    return {
      ...defaultCompanyInfo,
      ...parsed,
      custom_fields: Array.isArray(parsed.custom_fields)
        ? parsed.custom_fields
        : defaultCompanyInfo.custom_fields,
    };
  } catch {
    return defaultCompanyInfo;
  }
}

function saveCompanyToDatabase(company: CompanyInfo): void {
  localStorage.setItem(COMPANY_STORAGE_KEY, JSON.stringify(company));
}

function createCustomField(): CustomField {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    key: "",
    label: "",
    value: "",
  };
}

function SetCompany() {
  const [form, setForm] = useState<CompanyInfo>(defaultCompanyInfo);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<string>("");

  useEffect(() => {
    setForm(loadCompanyFromDatabase());
  }, []);

  const canSubmit = useMemo(() => {
    return (
      form.short_name.trim() &&
      form.full_name.trim() &&
      form.email.trim() &&
      form.phone.trim()
    );
  }, [form]);

  function updateField<K extends keyof CompanyInfo>(
    field: K,
    value: CompanyInfo[K],
  ) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  function addCustomField() {
    setForm((prev) => ({
      ...prev,
      custom_fields: [...prev.custom_fields, createCustomField()],
    }));
  }

  function updateCustomField(
    id: string,
    field: keyof Omit<CustomField, "id">,
    value: string,
  ) {
    setForm((prev) => ({
      ...prev,
      custom_fields: prev.custom_fields.map((item) =>
        item.id === id ? { ...item, [field]: value } : item,
      ),
    }));
  }

  function removeCustomField(id: string) {
    setForm((prev) => ({
      ...prev,
      custom_fields: prev.custom_fields.filter((item) => item.id !== id),
    }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) {
      setMessage(
        "Vui lòng nhập đủ tên ngắn, tên đầy đủ, email và số điện thoại.",
      );
      return;
    }

    setIsSaving(true);
    setMessage("");

    window.setTimeout(() => {
      const payload: CompanyInfo = {
        ...form,
        id: defaultCompanyInfo.id,
        updated_at: new Date().toISOString().slice(0, 19).replace("T", " "),
      };
      saveCompanyToDatabase(payload);
      setForm(payload);
      setIsSaving(false);
      setMessage("Đã cập nhật thông tin công ty vào database thành công.");
    }, 450);
  }

  return (
    <section className="company-page">
      <header className="topbar">
        <div>
          <p className="eyebrow">Thiết lập</p>
          <h1>Thông tin công ty</h1>
        </div>
      </header>

      <article className="panel company-panel">
        <div className="panel-head">
          <h2>Cập nhật hồ sơ doanh nghiệp</h2>
        </div>

        <form className="company-form" onSubmit={handleSubmit}>
          <label className="field field-wide">
            <span>Tên ngắn (short_name)</span>
            <input
              type="text"
              value={form.short_name}
              onChange={(e) => updateField("short_name", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Tên đầy đủ (full_name)</span>
            <input
              type="text"
              value={form.full_name}
              onChange={(e) => updateField("full_name", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Khẩu hiệu (slogan)</span>
            <input
              type="text"
              value={form.slogan}
              onChange={(e) => updateField("slogan", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Mã số thuế (tax_code)</span>
            <input
              type="text"
              value={form.tax_code}
              onChange={(e) => updateField("tax_code", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Năm thành lập (established_year)</span>
            <input
              type="number"
              value={form.established_year}
              onChange={(e) =>
                updateField("established_year", Number(e.target.value) || 0)
              }
            />
          </label>

          <label className="field">
            <span>Số điện thoại (phone)</span>
            <input
              type="text"
              value={form.phone}
              onChange={(e) => updateField("phone", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Đường dây nóng (hotline)</span>
            <input
              type="text"
              value={form.hotline}
              onChange={(e) => updateField("hotline", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Thư điện tử (email)</span>
            <input
              type="email"
              value={form.email}
              onChange={(e) => updateField("email", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Trang web (website)</span>
            <input
              type="url"
              value={form.website}
              onChange={(e) => updateField("website", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Địa chỉ (address)</span>
            <input
              type="text"
              value={form.address}
              onChange={(e) => updateField("address", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Đường dẫn bản đồ (map_address)</span>
            <input
              type="url"
              value={form.map_address}
              onChange={(e) => updateField("map_address", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Mã nhúng Google Map (google_map_embed)</span>
            <textarea
              rows={3}
              value={form.google_map_embed}
              onChange={(e) => updateField("google_map_embed", e.target.value)}
            />
          </label>

          <p className="company-section-title field-wide">Mạng xã hội</p>

          <label className="field">
            <span>Liên kết Facebook (facebook)</span>
            <input
              type="url"
              value={form.facebook}
              onChange={(e) => updateField("facebook", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Liên kết Zalo (zalo)</span>
            <input
              type="url"
              value={form.zalo}
              onChange={(e) => updateField("zalo", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Liên kết Telegram (telegram)</span>
            <input
              type="url"
              value={form.telegram}
              onChange={(e) => updateField("telegram", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Liên kết TikTok (tiktok)</span>
            <input
              type="url"
              value={form.tiktok}
              onChange={(e) => updateField("tiktok", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Liên kết Instagram (instagram)</span>
            <input
              type="text"
              value={form.instagram}
              onChange={(e) => updateField("instagram", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Liên kết YouTube (youtube)</span>
            <input
              type="text"
              value={form.youtube}
              onChange={(e) => updateField("youtube", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Liên kết WeChat (wechat)</span>
            <input
              type="text"
              value={form.wechat}
              onChange={(e) => updateField("wechat", e.target.value)}
            />
          </label>

          <p className="company-section-title field-wide">Hình ảnh và SEO</p>

          <label className="field">
            <span>Đường dẫn logo (logo_url)</span>
            <input
              type="text"
              value={form.logo_url}
              onChange={(e) => updateField("logo_url", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Đường dẫn ảnh giới thiệu (intro_image)</span>
            <input
              type="text"
              value={form.intro_image}
              onChange={(e) => updateField("intro_image", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Đường dẫn favicon (favicon_url)</span>
            <input
              type="text"
              value={form.favicon_url}
              onChange={(e) => updateField("favicon_url", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Tiêu đề SEO (meta_title)</span>
            <input
              type="text"
              value={form.meta_title}
              onChange={(e) => updateField("meta_title", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Mô tả SEO (meta_description)</span>
            <textarea
              rows={3}
              value={form.meta_description}
              onChange={(e) => updateField("meta_description", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Từ khóa SEO (meta_keywords)</span>
            <textarea
              rows={3}
              value={form.meta_keywords}
              onChange={(e) => updateField("meta_keywords", e.target.value)}
            />
          </label>

          <label className="field field-wide">
            <span>Giờ làm việc (working_hours)</span>
            <input
              type="text"
              value={form.working_hours}
              onChange={(e) => updateField("working_hours", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Trạng thái hoạt động (is_active)</span>
            <select
              value={String(form.is_active)}
              onChange={(e) =>
                updateField("is_active", Number(e.target.value) as 0 | 1)
              }
            >
              <option value="1">1 - Hoạt động</option>
              <option value="0">0 - Tạm dừng</option>
            </select>
          </label>

          <label className="field">
            <span>Ngày tạo (created_at)</span>
            <input type="text" value={form.created_at} readOnly />
          </label>

          <label className="field">
            <span>Ngày cập nhật (updated_at)</span>
            <input type="text" value={form.updated_at} readOnly />
          </label>

          <p className="company-section-title field-wide">
            Trường mở rộng tùy chỉnh
          </p>

          <div className="field-wide custom-fields-wrap">
            {form.custom_fields.length === 0 ? (
              <p className="custom-fields-empty">
                Chưa có trường mở rộng. Bạn có thể thêm mới bên dưới.
              </p>
            ) : null}

            {form.custom_fields.map((customField) => (
              <div className="custom-field-row" key={customField.id}>
                <label className="field">
                  <span>Tên hiển thị</span>
                  <input
                    type="text"
                    value={customField.label}
                    onChange={(e) =>
                      updateCustomField(customField.id, "label", e.target.value)
                    }
                    placeholder="Ví dụ: Mã kho"
                  />
                </label>

                <label className="field">
                  <span>Khóa (key)</span>
                  <input
                    type="text"
                    value={customField.key}
                    onChange={(e) =>
                      updateCustomField(customField.id, "key", e.target.value)
                    }
                    placeholder="warehouse_code"
                  />
                </label>

                <label className="field">
                  <span>Giá trị</span>
                  <input
                    type="text"
                    value={customField.value}
                    onChange={(e) =>
                      updateCustomField(customField.id, "value", e.target.value)
                    }
                    placeholder="Kho Hà Nội"
                  />
                </label>

                <button
                  type="button"
                  className="ghost-btn custom-field-delete"
                  onClick={() => removeCustomField(customField.id)}
                >
                  Xóa trường
                </button>
              </div>
            ))}

            <button
              type="button"
              className="ghost-btn custom-field-add"
              onClick={addCustomField}
            >
              + Thêm trường
            </button>
          </div>

          <div className="company-actions field-wide">
            <button className="primary-btn" type="submit" disabled={isSaving}>
              {isSaving ? "Đang lưu..." : "Lưu thay đổi"}
            </button>
            {message ? <p className="save-message">{message}</p> : null}
          </div>
        </form>
      </article>
    </section>
  );
}

export default SetCompany;
