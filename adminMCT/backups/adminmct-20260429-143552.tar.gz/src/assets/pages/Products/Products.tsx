import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import {
  useBrandContext,
  type BrandPayload,
  type ProductPayload,
} from "../../context/BrandContext/BrandContext.tsx";
import "./Products.css";

const defaultBrandForm: BrandPayload = {
  name: "",
  brand: "",
  is_active: 1,
};

const defaultProductForm: ProductPayload = {
  brand_id: 0,
  name: "",
  link: "",
  is_active: 1,
};

function Products() {
  const {
    brandItems,
    productItems,
    isLoadingProducts,
    productsMessage,
    refreshProductData,
    createBrandItem,
    updateBrandItem,
    deleteBrandItem,
    createProductItem,
    updateProductItem,
    deleteProductItem,
  } = useBrandContext();

  const [brandForm, setBrandForm] = useState<BrandPayload>(defaultBrandForm);
  const [productForm, setProductForm] =
    useState<ProductPayload>(defaultProductForm);
  const [editingBrandId, setEditingBrandId] = useState<number | null>(null);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const activeBrands = useMemo(
    () => brandItems.filter((item) => item.is_active === 1),
    [brandItems],
  );

  useEffect(() => {
    if (productForm.brand_id > 0) {
      return;
    }

    const firstBrand = activeBrands[0] ?? brandItems[0];
    if (firstBrand) {
      setProductForm((prev) => ({ ...prev, brand_id: firstBrand.id }));
    }
  }, [activeBrands, brandItems, productForm.brand_id]);

  function getBrandName(brandId: number): string {
    const brand = brandItems.find((item) => item.id === brandId);
    return brand ? brand.name : "Không xác định";
  }

  function handleStartEditBrand(id: number) {
    const target = brandItems.find((item) => item.id === id);
    if (!target) return;

    setEditingBrandId(target.id);
    setBrandForm({
      name: target.name,
      brand: target.brand,
      is_active: target.is_active,
    });
  }

  function handleStartEditProduct(id: number) {
    const target = productItems.find((item) => item.id === id);
    if (!target) return;

    setEditingProductId(target.id);
    setProductForm({
      brand_id: target.brand_id,
      name: target.name,
      link: target.link,
      is_active: target.is_active,
    });
  }

  function resetBrandForm() {
    setEditingBrandId(null);
    setBrandForm(defaultBrandForm);
  }

  function resetProductForm() {
    setEditingProductId(null);
    setProductForm((prev) => ({
      ...defaultProductForm,
      brand_id: prev.brand_id,
    }));
  }

  async function handleSubmitBrand(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!brandForm.name.trim() || !brandForm.brand.trim()) {
      setMessage("Vui lòng nhập tên nhãn hiệu và mã brand.");
      return;
    }

    setIsSubmitting(true);

    const result =
      editingBrandId === null
        ? await createBrandItem({
            name: brandForm.name.trim(),
            brand: brandForm.brand.trim(),
            is_active: brandForm.is_active,
          })
        : await updateBrandItem(editingBrandId, {
            name: brandForm.name.trim(),
            brand: brandForm.brand.trim(),
            is_active: brandForm.is_active,
          });

    if (!result.ok) {
      setMessage(result.message ?? "Thao tác nhãn hiệu thất bại.");
      setIsSubmitting(false);
      return;
    }

    setMessage(
      editingBrandId === null
        ? "Đã thêm nhãn hiệu mới."
        : `Đã cập nhật nhãn hiệu #${editingBrandId}.`,
    );
    resetBrandForm();
    setIsSubmitting(false);
  }

  async function handleDeleteBrand(id: number, name: string) {
    if (!window.confirm(`Xóa nhãn hiệu #${id} - ${name}?`)) {
      return;
    }

    setIsSubmitting(true);
    const result = await deleteBrandItem(id);

    if (!result.ok) {
      setMessage(result.message ?? "Không thể xóa nhãn hiệu.");
      setIsSubmitting(false);
      return;
    }

    if (editingBrandId === id) {
      resetBrandForm();
    }

    setMessage(`Đã xóa nhãn hiệu #${id}.`);
    setIsSubmitting(false);
  }

  async function handleSubmitProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (
      productForm.brand_id <= 0 ||
      !productForm.name.trim() ||
      !productForm.link.trim()
    ) {
      setMessage("Vui lòng chọn nhãn hiệu, nhập tên sản phẩm và link.");
      return;
    }

    setIsSubmitting(true);

    const result =
      editingProductId === null
        ? await createProductItem({
            brand_id: productForm.brand_id,
            name: productForm.name.trim(),
            link: productForm.link.trim(),
            is_active: productForm.is_active,
          })
        : await updateProductItem(editingProductId, {
            brand_id: productForm.brand_id,
            name: productForm.name.trim(),
            link: productForm.link.trim(),
            is_active: productForm.is_active,
          });

    if (!result.ok) {
      setMessage(result.message ?? "Thao tác sản phẩm thất bại.");
      setIsSubmitting(false);
      return;
    }

    setMessage(
      editingProductId === null
        ? "Đã thêm sản phẩm mới."
        : `Đã cập nhật sản phẩm #${editingProductId}.`,
    );
    resetProductForm();
    setIsSubmitting(false);
  }

  async function handleDeleteProduct(id: number, name: string) {
    if (!window.confirm(`Xóa sản phẩm #${id} - ${name}?`)) {
      return;
    }

    setIsSubmitting(true);
    const result = await deleteProductItem(id);

    if (!result.ok) {
      setMessage(result.message ?? "Không thể xóa sản phẩm.");
      setIsSubmitting(false);
      return;
    }

    if (editingProductId === id) {
      resetProductForm();
    }

    setMessage(`Đã xóa sản phẩm #${id}.`);
    setIsSubmitting(false);
  }

  return (
    <section className="products-page">
      <header className="topbar">
        <div>
          <p className="eyebrow">Quản lý dữ liệu</p>
          <h1>Quản lý sản phẩm</h1>
          {productsMessage ? (
            <p className="products-note">{productsMessage}</p>
          ) : null}
        </div>
        <button
          type="button"
          className="ghost-btn"
          onClick={() => void refreshProductData()}
          disabled={isLoadingProducts || isSubmitting}
        >
          {isLoadingProducts ? "Đang tải..." : "Tải lại dữ liệu"}
        </button>
      </header>

      <article className="panel products-panel">
        <div className="panel-head">
          <h2>1. Quản lý nhãn hiệu</h2>
        </div>

        <form className="products-form" onSubmit={handleSubmitBrand}>
          <label className="field field-wide">
            <span>Tên nhãn hiệu</span>
            <input
              type="text"
              value={brandForm.name}
              onChange={(e) =>
                setBrandForm((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="Ví dụ: Hitachi"
              disabled={isSubmitting}
            />
          </label>

          <label className="field field-wide">
            <span>Mã brand</span>
            <input
              type="text"
              value={brandForm.brand}
              onChange={(e) =>
                setBrandForm((prev) => ({ ...prev, brand: e.target.value }))
              }
              placeholder="Ví dụ: hitachi"
              disabled={isSubmitting}
            />
          </label>

          <label className="field">
            <span>Trạng thái</span>
            <button
              type="button"
              className={`switch ${brandForm.is_active === 1 ? "is-on" : "is-off"}`}
              onClick={() =>
                setBrandForm((prev) => ({
                  ...prev,
                  is_active: prev.is_active === 1 ? 0 : 1,
                }))
              }
              aria-pressed={brandForm.is_active === 1}
              disabled={isSubmitting}
            >
              <span className="switch-thumb" />
              <span className="switch-label">
                {brandForm.is_active === 1 ? "Đang bật" : "Đang tắt"}
              </span>
            </button>
          </label>

          <div className="products-actions field-wide">
            <button
              className="primary-btn"
              type="submit"
              disabled={isSubmitting}
            >
              {editingBrandId === null
                ? "Thêm nhãn hiệu"
                : "Cập nhật nhãn hiệu"}
            </button>
            {editingBrandId !== null ? (
              <button
                className="ghost-btn"
                type="button"
                onClick={resetBrandForm}
                disabled={isSubmitting}
              >
                Hủy sửa
              </button>
            ) : null}
          </div>
        </form>

        <div className="table-wrap">
          <table className="products-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nhãn hiệu</th>
                <th>Mã brand</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {brandItems.map((item) => (
                <tr key={item.id}>
                  <td>#{item.id}</td>
                  <td>{item.name}</td>
                  <td>{item.brand}</td>
                  <td>{item.is_active === 1 ? "Bật" : "Tắt"}</td>
                  <td className="products-row-actions">
                    <button
                      type="button"
                      className="row-action-btn"
                      onClick={() => handleStartEditBrand(item.id)}
                      disabled={isSubmitting}
                    >
                      Sửa
                    </button>
                    <button
                      type="button"
                      className="row-action-btn row-action-btn--danger"
                      onClick={() => void handleDeleteBrand(item.id, item.name)}
                      disabled={isSubmitting}
                    >
                      Xóa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>

      <article className="panel products-panel">
        <div className="panel-head">
          <h2>2. Quản lý sản phẩm theo nhãn hiệu</h2>
        </div>

        <form className="products-form" onSubmit={handleSubmitProduct}>
          <label className="field">
            <span>Nhãn hiệu</span>
            <select
              value={productForm.brand_id}
              onChange={(e) =>
                setProductForm((prev) => ({
                  ...prev,
                  brand_id: Number(e.target.value) || 0,
                }))
              }
              disabled={isSubmitting || brandItems.length === 0}
            >
              {brandItems.map((brand) => (
                <option key={brand.id} value={brand.id}>
                  #{brand.id} - {brand.name}
                </option>
              ))}
            </select>
          </label>

          <label className="field field-wide">
            <span>Tên sản phẩm</span>
            <input
              type="text"
              value={productForm.name}
              onChange={(e) =>
                setProductForm((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="Ví dụ: Máy xúc Hitachi ZX200"
              disabled={isSubmitting}
            />
          </label>

          <label className="field field-wide">
            <span>Link sản phẩm</span>
            <input
              type="url"
              value={productForm.link}
              onChange={(e) =>
                setProductForm((prev) => ({ ...prev, link: e.target.value }))
              }
              placeholder="https://..."
              disabled={isSubmitting}
            />
          </label>

          <label className="field">
            <span>Trạng thái</span>
            <button
              type="button"
              className={`switch ${productForm.is_active === 1 ? "is-on" : "is-off"}`}
              onClick={() =>
                setProductForm((prev) => ({
                  ...prev,
                  is_active: prev.is_active === 1 ? 0 : 1,
                }))
              }
              aria-pressed={productForm.is_active === 1}
              disabled={isSubmitting}
            >
              <span className="switch-thumb" />
              <span className="switch-label">
                {productForm.is_active === 1 ? "Đang bật" : "Đang tắt"}
              </span>
            </button>
          </label>

          <div className="products-actions field-wide">
            <button
              className="primary-btn"
              type="submit"
              disabled={isSubmitting || brandItems.length === 0}
            >
              {editingProductId === null
                ? "Thêm sản phẩm"
                : "Cập nhật sản phẩm"}
            </button>
            {editingProductId !== null ? (
              <button
                className="ghost-btn"
                type="button"
                onClick={resetProductForm}
                disabled={isSubmitting}
              >
                Hủy sửa
              </button>
            ) : null}
          </div>
        </form>

        <div className="table-wrap">
          <table className="products-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nhãn hiệu</th>
                <th>Tên sản phẩm</th>
                <th>Link</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {productItems.map((item) => (
                <tr key={item.id}>
                  <td>#{item.id}</td>
                  <td>{getBrandName(item.brand_id)}</td>
                  <td>{item.name}</td>
                  <td>
                    <a href={item.link} target="_blank" rel="noreferrer">
                      {item.link}
                    </a>
                  </td>
                  <td>{item.is_active === 1 ? "Bật" : "Tắt"}</td>
                  <td className="products-row-actions">
                    <button
                      type="button"
                      className="row-action-btn"
                      onClick={() => handleStartEditProduct(item.id)}
                      disabled={isSubmitting}
                    >
                      Sửa
                    </button>
                    <button
                      type="button"
                      className="row-action-btn row-action-btn--danger"
                      onClick={() =>
                        void handleDeleteProduct(item.id, item.name)
                      }
                      disabled={isSubmitting}
                    >
                      Xóa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>

      {message ? <p className="products-status">{message}</p> : null}
    </section>
  );
}

export default Products;
