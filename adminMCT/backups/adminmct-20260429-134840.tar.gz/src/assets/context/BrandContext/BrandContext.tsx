import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

export type BrandItem = {
  id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

export type ProductItem = {
  id: number;
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

export type BrandPayload = {
  name: string;
  is_active: 0 | 1;
};

export type ProductPayload = {
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
};

type ApiResult<T> = {
  ok: boolean;
  data?: T;
  message?: string;
};

type BrandContextValue = {
  brandItems: BrandItem[];
  productItems: ProductItem[];
  isLoadingProducts: boolean;
  productsMessage: string;
  refreshProductData: () => Promise<void>;
  createBrandItem: (payload: BrandPayload) => Promise<ApiResult<BrandItem>>;
  updateBrandItem: (
    id: number,
    payload: BrandPayload,
  ) => Promise<ApiResult<BrandItem>>;
  deleteBrandItem: (id: number) => Promise<ApiResult<null>>;
  createProductItem: (
    payload: ProductPayload,
  ) => Promise<ApiResult<ProductItem>>;
  updateProductItem: (
    id: number,
    payload: ProductPayload,
  ) => Promise<ApiResult<ProductItem>>;
  deleteProductItem: (id: number) => Promise<ApiResult<null>>;
};

type BrandContextProviderProps = {
  children: ReactNode;
};

const BRAND_API_CANDIDATES = [
  import.meta.env.VITE_BRANDS_API_ENDPOINT || "",
  "/api/brand_items",
  "/api/brand-items",
  "/api/brands",
].filter(Boolean);

const PRODUCT_API_CANDIDATES = [
  import.meta.env.VITE_PRODUCTS_API_ENDPOINT || "",
  "/api/product_items",
  "/api/product-items",
  "/api/products",
].filter(Boolean);

const BrandContext = createContext<BrandContextValue>({
  brandItems: [],
  productItems: [],
  isLoadingProducts: false,
  productsMessage: "",
  refreshProductData: async () => {},
  createBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  updateBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  deleteBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  createProductItem: async () => ({ ok: false, message: "Not implemented." }),
  updateProductItem: async () => ({ ok: false, message: "Not implemented." }),
  deleteProductItem: async () => ({ ok: false, message: "Not implemented." }),
});

let resolvedBrandEndpoint: string | null = null;
let resolvedProductEndpoint: string | null = null;

function getNowDateTime(): string {
  return new Date().toISOString().slice(0, 19).replace("T", " ");
}

function getAuthToken(): string {
  return localStorage.getItem("adminmct:token") ?? "";
}

function createSlug(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

function normalizeBrandRow(raw: unknown): BrandItem {
  const item = (raw ?? {}) as Record<string, unknown>;
  return {
    id: Number(item.id) || 0,
    name: String(item.name ?? item.title ?? ""),
    link: String(item.link ?? item.url ?? ""),
    is_active: Number(item.is_active) === 0 ? 0 : 1,
    created_at: String(item.created_at ?? item.createdAt ?? getNowDateTime()),
  };
}

function normalizeProductRow(raw: unknown): ProductItem {
  const item = (raw ?? {}) as Record<string, unknown>;
  return {
    id: Number(item.id) || 0,
    brand_id: Number(item.brand_id ?? item.brandId ?? 0) || 0,
    name: String(item.name ?? item.title ?? ""),
    link: String(item.link ?? item.url ?? ""),
    is_active: Number(item.is_active) === 0 ? 0 : 1,
    created_at: String(item.created_at ?? item.createdAt ?? getNowDateTime()),
  };
}

async function readResponseMessage(
  res: Response,
  fallback: string,
): Promise<string> {
  try {
    const data = (await res.json()) as { message?: string };
    return data.message ?? fallback;
  } catch {
    return fallback;
  }
}

async function resolveEndpoint(
  token: string,
  candidates: string[],
  cache: "brand" | "product",
): Promise<string> {
  const current =
    cache === "brand" ? resolvedBrandEndpoint : resolvedProductEndpoint;
  if (current) {
    return current;
  }

  for (const endpoint of candidates) {
    try {
      const res = await fetch(endpoint, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status !== 404) {
        if (cache === "brand") {
          resolvedBrandEndpoint = endpoint;
        } else {
          resolvedProductEndpoint = endpoint;
        }
        return endpoint;
      }
    } catch {
      // Try next endpoint.
    }
  }

  const fallback = candidates[0] || "/api";
  if (cache === "brand") {
    resolvedBrandEndpoint = fallback;
  } else {
    resolvedProductEndpoint = fallback;
  }

  return fallback;
}

async function readListPayload<T>(res: Response): Promise<T[]> {
  const payload = (await res.json()) as
    | T[]
    | {
        items?: T[];
        data?: T[];
        rows?: T[];
        list?: T[];
        brands?: T[];
        products?: T[];
        brand_items?: T[];
        product_items?: T[];
      };

  if (Array.isArray(payload)) {
    return payload;
  }

  if (Array.isArray(payload.items)) {
    return payload.items;
  }

  if (Array.isArray(payload.data)) {
    return payload.data;
  }

  if (Array.isArray(payload.rows)) {
    return payload.rows;
  }

  if (Array.isArray(payload.list)) {
    return payload.list;
  }

  if (Array.isArray(payload.brands)) {
    return payload.brands;
  }

  if (Array.isArray(payload.products)) {
    return payload.products;
  }

  if (Array.isArray(payload.brand_items)) {
    return payload.brand_items;
  }

  if (Array.isArray(payload.product_items)) {
    return payload.product_items;
  }

  return [];
}

async function requestMutation<T>(
  endpoint: string,
  method: "POST" | "PUT" | "DELETE",
  body?: unknown,
): Promise<ApiResult<T>> {
  const token = getAuthToken();
  if (!token) {
    return { ok: false, message: "Thiếu token đăng nhập." };
  }

  try {
    const res = await fetch(endpoint, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      return {
        ok: false,
        message: await readResponseMessage(res, "Thao tác API thất bại."),
      };
    }

    if (method === "DELETE") {
      return { ok: true, data: null as T };
    }

    const data = (await res.json()) as T | { item?: T; data?: T };
    const value =
      typeof data === "object" &&
      data !== null &&
      ("item" in data || "data" in data)
        ? (((data as { item?: T }).item ?? (data as { data?: T }).data) as T)
        : (data as T);

    return { ok: true, data: value };
  } catch {
    return { ok: false, message: "Không kết nối được API." };
  }
}

export function BrandContextProvider({ children }: BrandContextProviderProps) {
  const [brandItems, setBrandItems] = useState<BrandItem[]>([]);
  const [productItems, setProductItems] = useState<ProductItem[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [productsMessage, setProductsMessage] = useState("");

  async function refreshProductData() {
    const token = getAuthToken();
    if (!token) {
      setBrandItems([]);
      setProductItems([]);
      setProductsMessage("Thiếu token đăng nhập.");
      return;
    }

    setIsLoadingProducts(true);

    try {
      const [brandEndpoint, productEndpoint] = await Promise.all([
        resolveEndpoint(token, BRAND_API_CANDIDATES, "brand"),
        resolveEndpoint(token, PRODUCT_API_CANDIDATES, "product"),
      ]);

      const [brandRes, productRes] = await Promise.all([
        fetch(brandEndpoint, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(productEndpoint, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (!brandRes.ok) {
        const message = await readResponseMessage(
          brandRes,
          "Không tải được dữ liệu brand_items.",
        );
        setBrandItems([]);
        setProductItems([]);
        setProductsMessage(message);
        setIsLoadingProducts(false);
        return;
      }

      if (!productRes.ok) {
        const message = await readResponseMessage(
          productRes,
          "Không tải được dữ liệu product_items.",
        );
        setBrandItems([]);
        setProductItems([]);
        setProductsMessage(message);
        setIsLoadingProducts(false);
        return;
      }

      const [brandRaw, productRaw] = await Promise.all([
        readListPayload<unknown>(brandRes),
        readListPayload<unknown>(productRes),
      ]);

      setBrandItems(
        brandRaw
          .map((item) => normalizeBrandRow(item))
          .filter((item) => item.id > 0)
          .sort((a, b) => a.id - b.id),
      );
      setProductItems(
        productRaw
          .map((item) => normalizeProductRow(item))
          .filter((item) => item.id > 0)
          .sort((a, b) => b.id - a.id),
      );
      setProductsMessage("");
      setIsLoadingProducts(false);
    } catch {
      setBrandItems([]);
      setProductItems([]);
      setProductsMessage("Không kết nối được API.");
      setIsLoadingProducts(false);
    }
  }

  async function createBrandItem(payload: BrandPayload) {
    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      BRAND_API_CANDIDATES,
      "brand",
    );

    const result = await requestMutation<BrandItem>(endpoint, "POST", {
      name: payload.name.trim(),
      link: `/product/${createSlug(payload.name)}`,
      is_active: payload.is_active,
    });

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data ? normalizeBrandRow(result.data) : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function updateBrandItem(id: number, payload: BrandPayload) {
    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      BRAND_API_CANDIDATES,
      "brand",
    );

    const result = await requestMutation<BrandItem>(
      `${endpoint}/${id}`,
      "PUT",
      {
        name: payload.name.trim(),
        link: `/product/${createSlug(payload.name)}`,
        is_active: payload.is_active,
      },
    );

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data ? normalizeBrandRow(result.data) : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function deleteBrandItem(id: number) {
    if (productItems.some((row) => row.brand_id === id)) {
      return {
        ok: false,
        message:
          "Nhãn hiệu đang có sản phẩm, vui lòng xóa/chuyển sản phẩm trước.",
      };
    }

    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      BRAND_API_CANDIDATES,
      "brand",
    );
    const result = await requestMutation<null>(`${endpoint}/${id}`, "DELETE");

    if (result.ok) {
      await refreshProductData();
    }

    return result;
  }

  async function createProductItem(payload: ProductPayload) {
    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      PRODUCT_API_CANDIDATES,
      "product",
    );

    const result = await requestMutation<ProductItem>(endpoint, "POST", {
      brand_id: payload.brand_id,
      name: payload.name.trim(),
      link: payload.link.trim(),
      is_active: payload.is_active,
    });

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data ? normalizeProductRow(result.data) : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function updateProductItem(id: number, payload: ProductPayload) {
    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      PRODUCT_API_CANDIDATES,
      "product",
    );

    const result = await requestMutation<ProductItem>(
      `${endpoint}/${id}`,
      "PUT",
      {
        brand_id: payload.brand_id,
        name: payload.name.trim(),
        link: payload.link.trim(),
        is_active: payload.is_active,
      },
    );

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data ? normalizeProductRow(result.data) : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function deleteProductItem(id: number) {
    const token = getAuthToken();
    const endpoint = await resolveEndpoint(
      token,
      PRODUCT_API_CANDIDATES,
      "product",
    );
    const result = await requestMutation<null>(`${endpoint}/${id}`, "DELETE");

    if (result.ok) {
      await refreshProductData();
    }

    return result;
  }

  useEffect(() => {
    void refreshProductData();
  }, []);

  const value = useMemo(
    () => ({
      brandItems,
      productItems,
      isLoadingProducts,
      productsMessage,
      refreshProductData,
      createBrandItem,
      updateBrandItem,
      deleteBrandItem,
      createProductItem,
      updateProductItem,
      deleteProductItem,
    }),
    [brandItems, isLoadingProducts, productItems, productsMessage],
  );

  return (
    <BrandContext.Provider value={value}>{children}</BrandContext.Provider>
  );
}

export function useBrandContext(): BrandContextValue {
  return useContext(BrandContext);
}
