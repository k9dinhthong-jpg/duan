const crypto = require("crypto");
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const mysql = require("mysql2/promise");

const app = express();
app.use(express.json());

const mariaPool = mysql.createPool({
  host: process.env.MARIA_HOST || "127.0.0.1",
  port: Number(process.env.MARIA_PORT || 3306),
  user: process.env.MARIA_USER || "adminmct_api",
  password: process.env.MARIA_PASSWORD || "MctApi@2026!DB",
  database: process.env.MARIA_DB || "maycongtrinh_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.trim() !== "") {
    return forwarded.split(",")[0].trim();
  }
  return req.socket?.remoteAddress || "";
}

function getUserAgent(req) {
  return typeof req.headers["user-agent"] === "string"
    ? req.headers["user-agent"]
    : "";
}

async function logSecurity(adminId, action, req, meta = {}) {
  try {
    await mariaPool.execute(
      "INSERT INTO security_logs (admin_id, action, ip_address, user_agent, meta_json) VALUES (?, ?, ?, ?, ?)",
      [
        adminId,
        action,
        getClientIp(req),
        getUserAgent(req),
        JSON.stringify(meta),
      ],
    );
  } catch (err) {
    console.error("logSecurity error:", err);
  }
}

function getBearerToken(authHeader) {
  if (typeof authHeader !== "string") {
    return "";
  }
  if (!authHeader.startsWith("Bearer ")) {
    return "";
  }
  return authHeader.slice(7).trim();
}

function randomBase32(length = 32) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const bytes = crypto.randomBytes(length);
  let output = "";
  for (let i = 0; i < bytes.length; i += 1) {
    output += alphabet[bytes[i] % alphabet.length];
  }
  return output;
}

function base32ToBuffer(base32) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  const clean = String(base32 || "")
    .toUpperCase()
    .replace(/=+$/g, "");

  for (const char of clean) {
    const val = alphabet.indexOf(char);
    if (val === -1) {
      continue;
    }
    bits += val.toString(2).padStart(5, "0");
  }

  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }

  return Buffer.from(bytes);
}

function generateTotp(secret, time = Date.now()) {
  const key = base32ToBuffer(secret);
  const counter = Math.floor(time / 1000 / 30);
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));

  const hash = crypto.createHmac("sha1", key).update(msg).digest();
  const offset = hash[hash.length - 1] & 0x0f;
  const code =
    (((hash[offset] & 0x7f) << 24) |
      ((hash[offset + 1] & 0xff) << 16) |
      ((hash[offset + 2] & 0xff) << 8) |
      (hash[offset + 3] & 0xff)) %
    1000000;

  return String(code).padStart(6, "0");
}

function verifyTotp(secret, code) {
  const normalizedCode = String(code || "").replace(/\s+/g, "");
  if (!/^\d{6}$/.test(normalizedCode)) {
    return false;
  }

  const now = Date.now();
  for (let drift = -1; drift <= 1; drift += 1) {
    const candidate = generateTotp(secret, now + drift * 30000);
    if (candidate === normalizedCode) {
      return true;
    }
  }

  return false;
}

function issueAccessToken(user, sessionId) {
  return jwt.sign(
    {
      sub: user.id,
      username: user.username,
      role: "admin",
      sid: sessionId,
      tv: Number(user.token_version || 1),
    },
    process.env.JWT_SECRET,
    { expiresIn: "8h" },
  );
}

function requireAuth(req, res, next) {
  void (async () => {
    const token = getBearerToken(req.headers.authorization);
    if (!token) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      return res
        .status(401)
        .json({ message: "Token không hợp lệ hoặc đã hết hạn." });
    }

    const [rows] = await mariaPool.execute(
      "SELECT id, username, is_active, token_version, full_name, email, phone, twofa_enabled, twofa_secret, twofa_pending_secret FROM admins WHERE id = ? LIMIT 1",
      [Number(payload.sub)],
    );

    const user = Array.isArray(rows) ? rows[0] : null;
    if (!user || Number(user.is_active) !== 1) {
      return res.status(401).json({ message: "Tài khoản không hợp lệ." });
    }

    if (payload.tv && Number(payload.tv) !== Number(user.token_version || 1)) {
      return res
        .status(401)
        .json({ message: "Phiên đăng nhập đã hết hiệu lực." });
    }

    if (payload.sid) {
      const [sessionRows] = await mariaPool.execute(
        "SELECT id, revoked_at FROM admin_sessions WHERE id = ? AND admin_id = ? LIMIT 1",
        [String(payload.sid), Number(user.id)],
      );
      const session = Array.isArray(sessionRows) ? sessionRows[0] : null;

      if (!session || session.revoked_at) {
        return res
          .status(401)
          .json({ message: "Phiên đăng nhập đã bị thu hồi." });
      }

      await mariaPool.execute(
        "UPDATE admin_sessions SET last_seen_at = CURRENT_TIMESTAMP WHERE id = ?",
        [String(payload.sid)],
      );
    }

    req.auth = {
      ...payload,
      user,
    };

    return next();
  })().catch((err) => {
    console.error("requireAuth error:", err);
    return res.status(500).json({ message: "Lỗi xác thực hệ thống." });
  });
}

app.post("/api/auth/login", async (req, res) => {
  const username =
    typeof req.body?.username === "string" ? req.body.username.trim() : "";
  const password =
    typeof req.body?.password === "string" ? req.body.password : "";
  const twoFactorCode =
    typeof req.body?.twoFactorCode === "string" ? req.body.twoFactorCode : "";

  if (username === "" || password === "") {
    return res.status(400).json({ message: "Missing credentials" });
  }

  const [rows] = await mariaPool.execute(
    "SELECT id, username, full_name, password_hash, is_active, twofa_enabled, twofa_secret, token_version FROM admins WHERE username = ? AND is_active = 1 LIMIT 1",
    [username],
  );
  const user = Array.isArray(rows) ? rows[0] : null;

  if (!user) {
    return res.status(401).json({ message: "Invalid username or password" });
  }

  const isValid = bcrypt.compareSync(password, user.password_hash);
  if (!isValid) {
    await logSecurity(user.id, "LOGIN_FAILED", req, {
      username,
      reason: "wrong_password",
    });
    return res.status(401).json({ message: "Invalid username or password" });
  }

  if (Number(user.twofa_enabled) === 1) {
    if (!twoFactorCode) {
      return res.status(200).json({
        requiresTwoFactor: true,
        message: "Vui lòng nhập mã xác thực 2FA để tiếp tục.",
      });
    }

    if (!verifyTotp(user.twofa_secret || "", twoFactorCode)) {
      await logSecurity(user.id, "LOGIN_FAILED", req, {
        username,
        reason: "invalid_2fa_code",
      });
      return res.status(401).json({ message: "Mã 2FA không đúng." });
    }
  }

  const sessionId = crypto.randomUUID();
  await mariaPool.execute(
    "INSERT INTO admin_sessions (id, admin_id, ip_address, user_agent) VALUES (?, ?, ?, ?)",
    [sessionId, user.id, getClientIp(req), getUserAgent(req)],
  );

  const token = issueAccessToken(user, sessionId);

  await logSecurity(user.id, "LOGIN_SUCCESS", req, { sessionId });

  return res.json({
    token,
    name: user.full_name || user.username,
  });
});

app.get("/api/account/profile", requireAuth, async (req, res) => {
  const user = req.auth.user;

  return res.json({
    username: user.username,
    name: user.full_name || user.username,
    email: user.email || "",
    phone: user.phone || "",
  });
});

app.put("/api/account/profile", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  const email =
    typeof req.body?.email === "string" ? req.body.email.trim() : "";
  const phone =
    typeof req.body?.phone === "string" ? req.body.phone.trim() : "";

  if (name === "") {
    return res.status(400).json({ message: "Vui lòng nhập họ và tên." });
  }

  await mariaPool.execute(
    "UPDATE admins SET full_name = ?, email = ?, phone = ? WHERE id = ?",
    [name, email, phone, userId],
  );

  await logSecurity(userId, "PROFILE_UPDATED", req, { name, email, phone });

  const [rows] = await mariaPool.execute(
    "SELECT username, full_name, email, phone FROM admins WHERE id = ? LIMIT 1",
    [userId],
  );
  const updated = Array.isArray(rows) ? rows[0] : null;

  return res.json({
    username: updated?.username || "",
    name: updated?.full_name || updated?.username || "",
    email: updated?.email || "",
    phone: updated?.phone || "",
  });
});

app.put("/api/account/password", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const currentSessionId = typeof req.auth.sid === "string" ? req.auth.sid : "";
  const currentPassword =
    typeof req.body?.currentPassword === "string"
      ? req.body.currentPassword
      : "";
  const newPassword =
    typeof req.body?.newPassword === "string" ? req.body.newPassword : "";

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ message: "Thiếu thông tin mật khẩu." });
  }

  if (newPassword.length < 8) {
    return res
      .status(400)
      .json({ message: "Mật khẩu mới phải có ít nhất 8 ký tự." });
  }

  const [rows] = await mariaPool.execute(
    "SELECT password_hash FROM admins WHERE id = ? LIMIT 1",
    [userId],
  );
  const user = Array.isArray(rows) ? rows[0] : null;
  if (!user) {
    return res.status(404).json({ message: "Không tìm thấy tài khoản." });
  }

  const matched = bcrypt.compareSync(currentPassword, user.password_hash);
  if (!matched) {
    return res.status(400).json({ message: "Mật khẩu hiện tại không đúng." });
  }

  const newHash = bcrypt.hashSync(newPassword, 12);
  await mariaPool.execute("UPDATE admins SET password_hash = ? WHERE id = ?", [
    newHash,
    userId,
  ]);

  if (currentSessionId) {
    await mariaPool.execute(
      "UPDATE admin_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND id != ?",
      [userId, currentSessionId],
    );
  }

  await logSecurity(userId, "PASSWORD_CHANGED", req, {
    revokeOtherSessions: Boolean(currentSessionId),
  });

  return res.json({ ok: true });
});

app.get("/api/account/2fa/status", requireAuth, async (req, res) => {
  const user = req.auth.user;
  return res.json({
    enabled: Number(user.twofa_enabled) === 1,
    hasPendingSetup: Boolean(user.twofa_pending_secret),
  });
});

app.post("/api/account/2fa/setup", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const username = req.auth.user.username;
  const secret = randomBase32(32);

  await mariaPool.execute(
    "UPDATE admins SET twofa_pending_secret = ? WHERE id = ?",
    [secret, userId],
  );

  const label = encodeURIComponent(`AdminMCT:${username}`);
  const issuer = encodeURIComponent("AdminMCT");
  const otpauthUrl = `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;

  await logSecurity(userId, "TWO_FACTOR_SETUP_CREATED", req, {});

  return res.json({
    secret,
    otpauthUrl,
  });
});

app.post("/api/account/2fa/enable", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const code = typeof req.body?.code === "string" ? req.body.code : "";

  const [rows] = await mariaPool.execute(
    "SELECT twofa_pending_secret FROM admins WHERE id = ? LIMIT 1",
    [userId],
  );
  const row = Array.isArray(rows) ? rows[0] : null;
  const pendingSecret = row?.twofa_pending_secret || "";
  if (!pendingSecret) {
    return res
      .status(400)
      .json({ message: "Chưa có thiết lập 2FA chờ kích hoạt." });
  }

  if (!verifyTotp(pendingSecret, code)) {
    return res.status(400).json({ message: "Mã 2FA không hợp lệ." });
  }

  await mariaPool.execute(
    "UPDATE admins SET twofa_enabled = 1, twofa_secret = ?, twofa_pending_secret = NULL WHERE id = ?",
    [pendingSecret, userId],
  );

  await logSecurity(userId, "TWO_FACTOR_ENABLED", req, {});

  return res.json({ ok: true });
});

app.post("/api/account/2fa/disable", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const currentPassword =
    typeof req.body?.currentPassword === "string"
      ? req.body.currentPassword
      : "";

  if (!currentPassword) {
    return res
      .status(400)
      .json({ message: "Vui lòng nhập mật khẩu hiện tại." });
  }

  const [rows] = await mariaPool.execute(
    "SELECT password_hash, twofa_enabled FROM admins WHERE id = ? LIMIT 1",
    [userId],
  );
  const user = Array.isArray(rows) ? rows[0] : null;

  if (!user) {
    return res.status(404).json({ message: "Không tìm thấy tài khoản." });
  }

  if (Number(user.twofa_enabled) !== 1) {
    return res.status(400).json({ message: "2FA chưa được bật." });
  }

  const matched = bcrypt.compareSync(currentPassword, user.password_hash);
  if (!matched) {
    return res.status(400).json({ message: "Mật khẩu hiện tại không đúng." });
  }

  await mariaPool.execute(
    "UPDATE admins SET twofa_enabled = 0, twofa_secret = NULL, twofa_pending_secret = NULL WHERE id = ?",
    [userId],
  );

  await logSecurity(userId, "TWO_FACTOR_DISABLED", req, {});

  return res.json({ ok: true });
});

app.get("/api/account/sessions", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const currentSessionId = typeof req.auth.sid === "string" ? req.auth.sid : "";

  const [rows] = await mariaPool.execute(
    "SELECT id, ip_address, user_agent, created_at, last_seen_at FROM admin_sessions WHERE admin_id = ? AND revoked_at IS NULL ORDER BY created_at DESC",
    [userId],
  );

  const items = (Array.isArray(rows) ? rows : []).map((row) => ({
    id: row.id,
    ipAddress: row.ip_address || "",
    userAgent: row.user_agent || "",
    createdAt: row.created_at,
    lastSeenAt: row.last_seen_at,
    isCurrent: currentSessionId ? row.id === currentSessionId : false,
  }));

  return res.json({ items });
});

app.delete(
  "/api/account/sessions/:sessionId",
  requireAuth,
  async (req, res) => {
    const userId = Number(req.auth.sub);
    const currentSessionId =
      typeof req.auth.sid === "string" ? req.auth.sid : "";
    const sessionId = String(req.params.sessionId || "");

    if (sessionId === "") {
      return res.status(400).json({ message: "Session không hợp lệ." });
    }

    if (currentSessionId && sessionId === currentSessionId) {
      return res
        .status(400)
        .json({ message: "Không thể tự thu hồi phiên hiện tại." });
    }

    const [rows] = await mariaPool.execute(
      "SELECT id FROM admin_sessions WHERE id = ? AND admin_id = ? AND revoked_at IS NULL LIMIT 1",
      [sessionId, userId],
    );
    const exists = Array.isArray(rows) && rows.length > 0;

    if (!exists) {
      return res
        .status(404)
        .json({ message: "Không tìm thấy phiên đăng nhập." });
    }

    await mariaPool.execute(
      "UPDATE admin_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?",
      [sessionId],
    );
    await logSecurity(userId, "SESSION_REVOKED", req, { sessionId });

    return res.json({ ok: true });
  },
);

app.post(
  "/api/account/sessions/revoke-others",
  requireAuth,
  async (req, res) => {
    const userId = Number(req.auth.sub);
    const currentSessionId =
      typeof req.auth.sid === "string" ? req.auth.sid : "";

    if (currentSessionId) {
      await mariaPool.execute(
        "UPDATE admin_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND id != ? AND revoked_at IS NULL",
        [userId, currentSessionId],
      );
    } else {
      await mariaPool.execute(
        "UPDATE admin_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND revoked_at IS NULL",
        [userId],
      );
    }

    await logSecurity(userId, "OTHER_SESSIONS_REVOKED", req, {});

    return res.json({ ok: true });
  },
);

app.get("/api/account/security-logs", requireAuth, async (req, res) => {
  const userId = Number(req.auth.sub);
  const limitRaw = Number(req.query.limit || 20);
  const limit = Number.isFinite(limitRaw)
    ? Math.min(Math.max(limitRaw, 1), 100)
    : 20;

  const [rows] = await mariaPool.execute(
    "SELECT id, action, ip_address, user_agent, meta_json, created_at FROM security_logs WHERE admin_id = ? ORDER BY created_at DESC LIMIT ?",
    [userId, limit],
  );

  return res.json({
    items: (Array.isArray(rows) ? rows : []).map((row) => {
      let meta = {};
      try {
        meta = row.meta_json ? JSON.parse(row.meta_json) : {};
      } catch {
        meta = {};
      }

      return {
        id: row.id,
        action: row.action,
        ipAddress: row.ip_address || "",
        userAgent: row.user_agent || "",
        createdAt: row.created_at,
        meta,
      };
    }),
  });
});

app.get("/api/company-info", requireAuth, async (_req, res) => {
  try {
    const [rows] = await mariaPool.query(
      "SELECT * FROM company_info WHERE id = 1 LIMIT 1",
    );

    if (!Array.isArray(rows) || rows.length === 0) {
      return res
        .status(404)
        .json({ message: "Không tìm thấy thông tin công ty." });
    }

    const row = rows[0];
    let customFields = [];
    try {
      customFields = row.custom_fields_json
        ? JSON.parse(row.custom_fields_json)
        : [];
      if (!Array.isArray(customFields)) {
        customFields = [];
      }
    } catch {
      customFields = [];
    }

    return res.json({
      id: Number(row.id || 1),
      short_name: row.short_name || "",
      full_name: row.full_name || "",
      slogan: row.slogan || "",
      about: row.about || "",
      tax_code: row.tax_code || "",
      business_license: row.business_license || "",
      legal_representative: row.legal_representative || "",
      established_year: Number(row.established_year || 0),
      phone: row.phone || "",
      hotline: row.hotline || "",
      email: row.email || "",
      contact_email: row.contact_email || "",
      website: row.website || "",
      address: row.address || "",
      map_address: row.map_address || "",
      google_map_embed: row.google_map_embed || "",
      facebook: row.facebook || "",
      zalo: row.zalo || "",
      whatsapp: row.whatsapp || "",
      telegram: row.telegram || "",
      tiktok: row.tiktok || "",
      instagram: row.instagram || "",
      youtube: row.youtube || "",
      wechat: row.wechat || "",
      logo_url: row.logo_url || "",
      intro_image: row.intro_image || "",
      og_image: row.og_image || "",
      favicon_url: row.favicon_url || "",
      meta_title: row.meta_title || "",
      meta_description: row.meta_description || "",
      meta_keywords: row.meta_keywords || "",
      copyright_text: row.copyright_text || "",
      working_hours: row.working_hours || "",
      is_active: Number(row.is_active) === 0 ? 0 : 1,
      created_at: row.created_at
        ? new Date(row.created_at).toISOString().slice(0, 19).replace("T", " ")
        : "",
      updated_at: row.updated_at
        ? new Date(row.updated_at).toISOString().slice(0, 19).replace("T", " ")
        : "",
      custom_fields: customFields,
    });
  } catch (err) {
    console.error("GET /api/company-info error:", err);
    return res
      .status(500)
      .json({ message: "Lỗi đọc dữ liệu company từ MariaDB." });
  }
});

app.put("/api/company-info", requireAuth, async (req, res) => {
  const body = req.body || {};
  const shortName =
    typeof body.short_name === "string" ? body.short_name.trim() : "";
  const fullName =
    typeof body.full_name === "string" ? body.full_name.trim() : "";
  const email = typeof body.email === "string" ? body.email.trim() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";

  if (!shortName || !fullName || !email || !phone) {
    return res.status(400).json({
      message:
        "Thiếu các trường bắt buộc: short_name, full_name, email, phone.",
    });
  }

  const customFields = Array.isArray(body.custom_fields)
    ? body.custom_fields
    : [];

  try {
    const [existing] = await mariaPool.query(
      "SELECT id FROM company_info WHERE id = 1 LIMIT 1",
    );

    if (!Array.isArray(existing) || existing.length === 0) {
      await mariaPool.query(
        "INSERT INTO company_info (id, short_name, full_name, email, phone) VALUES (1, ?, ?, ?, ?)",
        [shortName, fullName, email, phone],
      );
    }

    await mariaPool.query(
      "UPDATE company_info SET short_name = ?, full_name = ?, slogan = ?, about = ?, tax_code = ?, business_license = ?, legal_representative = ?, established_year = ?, phone = ?, hotline = ?, email = ?, contact_email = ?, website = ?, address = ?, map_address = ?, google_map_embed = ?, facebook = ?, zalo = ?, whatsapp = ?, telegram = ?, tiktok = ?, instagram = ?, youtube = ?, wechat = ?, logo_url = ?, intro_image = ?, og_image = ?, favicon_url = ?, meta_title = ?, meta_description = ?, meta_keywords = ?, copyright_text = ?, working_hours = ?, is_active = ?, custom_fields_json = ? WHERE id = 1",
      [
        shortName,
        fullName,
        typeof body.slogan === "string" ? body.slogan.trim() : "",
        typeof body.about === "string" ? body.about.trim() : "",
        typeof body.tax_code === "string" ? body.tax_code.trim() : "",
        typeof body.business_license === "string"
          ? body.business_license.trim()
          : "",
        typeof body.legal_representative === "string"
          ? body.legal_representative.trim()
          : "",
        Number.isFinite(Number(body.established_year))
          ? Number(body.established_year)
          : 0,
        phone,
        typeof body.hotline === "string" ? body.hotline.trim() : "",
        email,
        typeof body.contact_email === "string" ? body.contact_email.trim() : "",
        typeof body.website === "string" ? body.website.trim() : "",
        typeof body.address === "string" ? body.address.trim() : "",
        typeof body.map_address === "string" ? body.map_address.trim() : "",
        typeof body.google_map_embed === "string" ? body.google_map_embed : "",
        typeof body.facebook === "string" ? body.facebook.trim() : "",
        typeof body.zalo === "string" ? body.zalo.trim() : "",
        typeof body.whatsapp === "string" ? body.whatsapp.trim() : "",
        typeof body.telegram === "string" ? body.telegram.trim() : "",
        typeof body.tiktok === "string" ? body.tiktok.trim() : "",
        typeof body.instagram === "string" ? body.instagram.trim() : "",
        typeof body.youtube === "string" ? body.youtube.trim() : "",
        typeof body.wechat === "string" ? body.wechat.trim() : "",
        typeof body.logo_url === "string" ? body.logo_url.trim() : "",
        typeof body.intro_image === "string" ? body.intro_image.trim() : "",
        typeof body.og_image === "string" ? body.og_image.trim() : "",
        typeof body.favicon_url === "string" ? body.favicon_url.trim() : "",
        typeof body.meta_title === "string" ? body.meta_title.trim() : "",
        typeof body.meta_description === "string"
          ? body.meta_description.trim()
          : "",
        typeof body.meta_keywords === "string" ? body.meta_keywords.trim() : "",
        typeof body.copyright_text === "string"
          ? body.copyright_text.trim()
          : "",
        typeof body.working_hours === "string" ? body.working_hours.trim() : "",
        Number(body.is_active) === 0 ? 0 : 1,
        JSON.stringify(customFields),
      ],
    );

    return res.json({ ok: true });
  } catch (err) {
    console.error("PUT /api/company-info error:", err);
    return res
      .status(500)
      .json({ message: "Lỗi ghi dữ liệu company vào MariaDB." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

async function ensureCompanyColumns() {
  const columns = [
    ["about", "TEXT NULL"],
    ["business_license", "VARCHAR(100) NULL"],
    ["legal_representative", "VARCHAR(255) NULL"],
    ["contact_email", "VARCHAR(255) NULL"],
    ["whatsapp", "VARCHAR(500) NULL"],
    ["og_image", "VARCHAR(500) NULL"],
    ["copyright_text", "TEXT NULL"],
    ["custom_fields_json", "LONGTEXT NULL"],
  ];

  for (const [name, def] of columns) {
    await mariaPool.query(
      `ALTER TABLE company_info ADD COLUMN IF NOT EXISTS ${name} ${def}`,
    );
  }
}

async function initSchema() {
  await mariaPool.query(
    "CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(120) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, is_active TINYINT NOT NULL DEFAULT 1, full_name VARCHAR(255) NULL, email VARCHAR(255) NULL, phone VARCHAR(50) NULL, twofa_enabled TINYINT NOT NULL DEFAULT 0, twofa_secret TEXT NULL, twofa_pending_secret TEXT NULL, token_version INT NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)",
  );

  await mariaPool.query(
    "CREATE TABLE IF NOT EXISTS admin_sessions (id VARCHAR(64) PRIMARY KEY, admin_id INT NOT NULL, ip_address VARCHAR(100) NULL, user_agent TEXT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, revoked_at TIMESTAMP NULL, INDEX idx_admin_sessions_admin_id (admin_id))",
  );

  await mariaPool.query(
    "CREATE TABLE IF NOT EXISTS security_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY, admin_id INT NOT NULL, action VARCHAR(120) NOT NULL, ip_address VARCHAR(100) NULL, user_agent TEXT NULL, meta_json LONGTEXT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_security_logs_admin_created (admin_id, created_at))",
  );

  await ensureCompanyColumns();

  const [adminRows] = await mariaPool.query(
    "SELECT COUNT(*) AS c FROM admins WHERE is_active = 1",
  );
  const activeAdmins =
    Array.isArray(adminRows) && adminRows[0] ? Number(adminRows[0].c || 0) : 0;

  if (activeAdmins === 0) {
    const defaultHash = bcrypt.hashSync("admin123", 12);
    await mariaPool.execute(
      "INSERT INTO admins (username, password_hash, is_active, full_name) VALUES (?, ?, 1, ?)",
      ["admin", defaultHash, "Administrator"],
    );
  }
}

async function start() {
  await initSchema();
  const port = Number(process.env.PORT || 3002);
  app.listen(port, () => console.log("API running on port", port));
}

start().catch((err) => {
  console.error("Failed to start API:", err);
  process.exit(1);
});
