import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import "./Products.css";

type BrandItem = {
  id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

type ProductItem = {
  id: number;
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

type BrandForm = {
  name: string;
  link: string;
  is_active: 0 | 1;
};

type ProductForm = {
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
};

type CreateMode = "brand" | "product";

const BRANDS_STORAGE_KEY = "adminmct:product-brands";
const PRODUCTS_STORAGE_KEY = "adminmct:products";

const defaultBrands: BrandItem[] = [
  {
    id: 1,
    name: "Komatsu",
    link: "https://maycongtrinhnhapkhau.com.vn/komatsu",
    is_active: 1,
    created_at: "2026-04-28 11:10:00",
  },
  {
    id: 2,
    name: "Kobelco",
    link: "https://maycongtrinhnhapkhau.com.vn/kobelco",
    is_active: 1,
    created_at: "2026-04-28 11:12:00",
  },
];

const defaultProducts: ProductItem[] = [
  {
    id: 1,
    brand_id: 1,
    name: "Máy xúc Komatsu PC200",
    link: "https://maycongtrinhnhapkhau.com.vn/komatsu-pc200",
    is_active: 1,
    created_at: "2026-04-28 11:20:00",
  },
  {
    id: 2,
    brand_id: 2,
    name: "Máy đào Kobelco SK210",
    link: "https://maycongtrinhnhapkhau.com.vn/kobelco-sk210",
    is_active: 1,
    created_at: "2026-04-28 11:24:00",
  },
];

const defaultBrandForm: BrandForm = {
  name: "",
  link: "",
  is_active: 1,
};

const defaultProductForm: ProductForm = {
  brand_id: 1,
  name: "",
  link: "",
  is_active: 1,
};

function getNowDateTime(): string {
  return new Date().toISOString().slice(0, 19).replace("T", " ");
}

function loadBrands(): BrandItem[] {
  const raw = localStorage.getItem(BRANDS_STORAGE_KEY);
  if (!raw) {
    return defaultBrands;
  }

  try {
    const parsed = JSON.parse(raw) as BrandItem[];
    return Array.isArray(parsed) ? parsed : defaultBrands;
  } catch {
    return defaultBrands;
  }
}

function loadProducts(): ProductItem[] {
  const raw = localStorage.getItem(PRODUCTS_STORAGE_KEY);
  if (!raw) {
    return defaultProducts;
  }

  try {
    const parsed = JSON.parse(raw) as Array<
      ProductItem & { brand_id?: number }
    >;
    if (!Array.isArray(parsed)) {
      return defaultProducts;
    }

    return parsed.map((item) => ({
      ...item,
      brand_id: typeof item.brand_id === "number" ? item.brand_id : 1,
    }));
  } catch {
    return defaultProducts;
  }
}

function saveBrands(brands: BrandItem[]): void {
  localStorage.setItem(BRANDS_STORAGE_KEY, JSON.stringify(brands));
}

function saveProducts(products: ProductItem[]): void {
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
}

function Products() {
  const [mode, setMode] = useState<CreateMode>("brand");
  const [brands, setBrands] = useState<BrandItem[]>(defaultBrands);
  const [products, setProducts] = useState<ProductItem[]>(defaultProducts);
  const [brandForm, setBrandForm] = useState<BrandForm>(defaultBrandForm);
  const [productForm, setProductForm] =
    useState<ProductForm>(defaultProductForm);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const loadedBrands = loadBrands();
    setBrands(loadedBrands);
    setProducts(loadProducts());

    if (loadedBrands.length > 0) {
      setProductForm((prev) => ({ ...prev, brand_id: loadedBrands[0].id }));
    }
  }, []);

  const nextBrandId = useMemo(() => {
    if (brands.length === 0) return 1;
    return Math.max(...brands.map((item) => item.id)) + 1;
  }, [brands]);

  const nextProductId = useMemo(() => {
    if (products.length === 0) return 1;
    return Math.max(...products.map((item) => item.id)) + 1;
  }, [products]);

  const canAddBrand = useMemo(
    () => brandForm.name.trim() && brandForm.link.trim(),
    [brandForm],
  );

  const canAddProduct = useMemo(
    () =>
      brands.length > 0 && productForm.name.trim() && productForm.link.trim(),
    [brands.length, productForm],
  );

  function handleCreateBrand(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!canAddBrand) {
      setMessage("Vui lòng nhập đủ Tên hãng và Liên kết hãng.");
      return;
    }

    const newBrand: BrandItem = {
      id: nextBrandId,
      name: brandForm.name.trim(),
      link: brandForm.link.trim(),
      is_active: brandForm.is_active,
      created_at: getNowDateTime(),
    };

    const nextBrands = [newBrand, ...brands];
    setBrands(nextBrands);
    saveBrands(nextBrands);
    setBrandForm(defaultBrandForm);
    setProductForm((prev) => ({ ...prev, brand_id: newBrand.id }));
    setMessage(`Đã thêm hãng mới với ID #${newBrand.id}.`);
  }

  function handleCreateProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!canAddProduct) {
      setMessage(
        "Vui lòng chọn hãng và nhập đủ Tên sản phẩm, Liên kết sản phẩm.",
      );
      return;
    }

    const newProduct: ProductItem = {
      id: nextProductId,
      brand_id: productForm.brand_id,
      name: productForm.name.trim(),
      link: productForm.link.trim(),
      is_active: productForm.is_active,
      created_at: getNowDateTime(),
    };

    const nextProducts = [newProduct, ...products];
    setProducts(nextProducts);
    saveProducts(nextProducts);
    setProductForm((prev) => ({
      ...defaultProductForm,
      brand_id: prev.brand_id,
    }));
    setMessage(`Đã thêm sản phẩm mới với ID #${newProduct.id}.`);
  }

  function toggleBrandActive(id: number) {
    const nextBrands = brands.map((item) =>
      item.id === id
        ? {
            ...item,
            is_active: (item.is_active === 1 ? 0 : 1) as 0 | 1,
          }
        : item,
    );
    setBrands(nextBrands);
    saveBrands(nextBrands);
  }

  function toggleProductActive(id: number) {
    const nextProducts = products.map((item) =>
      item.id === id
        ? {
            ...item,
            is_active: (item.is_active === 1 ? 0 : 1) as 0 | 1,
          }
        : item,
    );
    setProducts(nextProducts);
    saveProducts(nextProducts);
  }

  function getBrandName(brandId: number): string {
    const brand = brands.find((item) => item.id === brandId);
    return brand ? brand.name : "Không xác định";
  }

  return (
    <section className="products-page">
      <header className="topbar">
        <div>
          <p className="eyebrow">Quản lý dữ liệu</p>
          <h1>Quản lý sản phẩm</h1>
        </div>
      </header>

      <article className="panel products-panel">
        <div className="panel-head">
          <h2>Tạo mới dữ liệu</h2>
        </div>

        <div className="mode-tabs">
          <button
            type="button"
            className={`mode-tab ${mode === "brand" ? "is-active" : ""}`}
            onClick={() => setMode("brand")}
          >
            Chế độ 1: Thêm hãng sản phẩm
          </button>
          <button
            type="button"
            className={`mode-tab ${mode === "product" ? "is-active" : ""}`}
            onClick={() => setMode("product")}
          >
            Chế độ 2: Thêm sản phẩm theo hãng có sẵn
          </button>
        </div>

        {mode === "brand" ? (
          <form className="products-form" onSubmit={handleCreateBrand}>
            <label className="field">
              <span>ID hãng (id)</span>
              <input type="number" value={nextBrandId} readOnly />
            </label>

            <label className="field field-wide">
              <span>Tên hãng (name)</span>
              <input
                type="text"
                value={brandForm.name}
                onChange={(e) =>
                  setBrandForm((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="Nhập tên hãng"
              />
            </label>

            <label className="field field-wide">
              <span>Liên kết hãng (link)</span>
              <input
                type="url"
                value={brandForm.link}
                onChange={(e) =>
                  setBrandForm((prev) => ({ ...prev, link: e.target.value }))
                }
                placeholder="https://..."
              />
            </label>

            <label className="field">
              <span>Trạng thái hoạt động (is_active)</span>
              <button
                type="button"
                className={`switch ${brandForm.is_active === 1 ? "is-on" : "is-off"}`}
                onClick={() =>
                  setBrandForm((prev) => ({
                    ...prev,
                    is_active: prev.is_active === 1 ? 0 : 1,
                  }))
                }
                aria-pressed={brandForm.is_active === 1}
              >
                <span className="switch-thumb" />
                <span className="switch-label">
                  {brandForm.is_active === 1 ? "Đang bật" : "Đang tắt"}
                </span>
              </button>
            </label>

            <div className="products-actions field-wide">
              <button className="primary-btn" type="submit">
                Thêm hãng sản phẩm
              </button>
              {message ? <p className="save-message">{message}</p> : null}
            </div>
          </form>
        ) : (
          <form className="products-form" onSubmit={handleCreateProduct}>
            <label className="field">
              <span>ID sản phẩm (id)</span>
              <input type="number" value={nextProductId} readOnly />
            </label>

            <label className="field">
              <span>Hãng sản phẩm (brand_id)</span>
              <select
                value={productForm.brand_id}
                onChange={(e) =>
                  setProductForm((prev) => ({
                    ...prev,
                    brand_id: Number(e.target.value) || prev.brand_id,
                  }))
                }
                disabled={brands.length === 0}
              >
                {brands.map((brand) => (
                  <option key={brand.id} value={brand.id}>
                    #{brand.id} - {brand.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="field field-wide">
              <span>Tên sản phẩm (name)</span>
              <input
                type="text"
                value={productForm.name}
                onChange={(e) =>
                  setProductForm((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="Nhập tên sản phẩm"
              />
            </label>

            <label className="field field-wide">
              <span>Liên kết sản phẩm (link)</span>
              <input
                type="url"
                value={productForm.link}
                onChange={(e) =>
                  setProductForm((prev) => ({ ...prev, link: e.target.value }))
                }
                placeholder="https://..."
              />
            </label>

            <label className="field">
              <span>Trạng thái hoạt động (is_active)</span>
              <button
                type="button"
                className={`switch ${productForm.is_active === 1 ? "is-on" : "is-off"}`}
                onClick={() =>
                  setProductForm((prev) => ({
                    ...prev,
                    is_active: prev.is_active === 1 ? 0 : 1,
                  }))
                }
                aria-pressed={productForm.is_active === 1}
              >
                <span className="switch-thumb" />
                <span className="switch-label">
                  {productForm.is_active === 1 ? "Đang bật" : "Đang tắt"}
                </span>
              </button>
            </label>

            <div className="products-actions field-wide">
              <button
                className="primary-btn"
                type="submit"
                disabled={brands.length === 0}
              >
                Thêm sản phẩm
              </button>
              {message ? <p className="save-message">{message}</p> : null}
            </div>
          </form>
        )}
      </article>

      <article className="panel products-panel">
        <div className="panel-head">
          <h2>Danh sách hãng sản phẩm</h2>
        </div>

        <div className="table-wrap">
          <table className="products-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Tên hãng</th>
                <th>Link</th>
                <th>Active</th>
                <th>Ngày tạo</th>
              </tr>
            </thead>
            <tbody>
              {brands.map((item) => (
                <tr key={item.id}>
                  <td>#{item.id}</td>
                  <td>{item.name}</td>
                  <td>
                    <a href={item.link} target="_blank" rel="noreferrer">
                      {item.link}
                    </a>
                  </td>
                  <td>
                    <button
                      type="button"
                      className={`switch switch-inline ${item.is_active === 1 ? "is-on" : "is-off"}`}
                      onClick={() => toggleBrandActive(item.id)}
                      aria-pressed={item.is_active === 1}
                    >
                      <span className="switch-thumb" />
                      <span className="switch-label">
                        {item.is_active === 1 ? "Bật" : "Tắt"}
                      </span>
                    </button>
                  </td>
                  <td>{item.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>

      <article className="panel products-panel">
        <div className="panel-head">
          <h2>Danh sách sản phẩm theo hãng</h2>
        </div>

        <div className="table-wrap">
          <table className="products-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Hãng</th>
                <th>Tên sản phẩm</th>
                <th>Link</th>
                <th>Active</th>
                <th>Ngày tạo</th>
              </tr>
            </thead>
            <tbody>
              {products.map((item) => (
                <tr key={item.id}>
                  <td>#{item.id}</td>
                  <td>{getBrandName(item.brand_id)}</td>
                  <td>{item.name}</td>
                  <td>
                    <a href={item.link} target="_blank" rel="noreferrer">
                      {item.link}
                    </a>
                  </td>
                  <td>
                    <button
                      type="button"
                      className={`switch switch-inline ${item.is_active === 1 ? "is-on" : "is-off"}`}
                      onClick={() => toggleProductActive(item.id)}
                      aria-pressed={item.is_active === 1}
                    >
                      <span className="switch-thumb" />
                      <span className="switch-label">
                        {item.is_active === 1 ? "Bật" : "Tắt"}
                      </span>
                    </button>
                  </td>
                  <td>{item.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
    </section>
  );
}

export default Products;
