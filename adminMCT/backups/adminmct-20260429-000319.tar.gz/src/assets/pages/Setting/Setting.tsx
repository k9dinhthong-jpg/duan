import { useEffect, useMemo, useState } from "react";
import "./Setting.css";

type SettingProps = {
  onAdminNameChange: (name: string) => void;
};

type AccountProfile = {
  name: string;
  username: string;
  email: string;
  phone: string;
};

type SecuritySetting = {
  loginAlert: boolean;
  autoLogoutIdle: boolean;
  maskSensitiveData: boolean;
};

type NotificationSetting = {
  orderAlert: boolean;
  inventoryAlert: boolean;
  weeklyReportEmail: boolean;
};

type TwoFactorStatus = {
  enabled: boolean;
  hasPendingSetup: boolean;
};

type SessionItem = {
  id: string;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
  lastSeenAt: string;
  isCurrent: boolean;
};

type SecurityLogItem = {
  id: number;
  action: string;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
  meta: Record<string, unknown>;
};

function readUsernameFromToken(): string {
  const token = localStorage.getItem("adminmct:token");
  if (!token) {
    return "admin";
  }

  try {
    const payload = token.split(".")[1];
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const json = JSON.parse(window.atob(normalized));
    return typeof json.username === "string" ? json.username : "admin";
  } catch {
    return "admin";
  }
}

function readObjectFromStorage<T>(key: string): Partial<T> | null {
  const raw = localStorage.getItem(key);

  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw) as Partial<T>;
  } catch {
    return null;
  }
}

function Setting({ onAdminNameChange }: SettingProps) {
  const profileFromStorage = useMemo(
    () => readObjectFromStorage<AccountProfile>("adminmct:account-profile"),
    [],
  );
  const securityFromStorage = useMemo(
    () => readObjectFromStorage<SecuritySetting>("adminmct:setting-security"),
    [],
  );
  const notificationsFromStorage = useMemo(
    () =>
      readObjectFromStorage<NotificationSetting>(
        "adminmct:setting-notifications",
      ),
    [],
  );

  const [profile, setProfile] = useState<AccountProfile>({
    name:
      profileFromStorage?.name ??
      localStorage.getItem("adminmct:admin-name") ??
      "",
    username: profileFromStorage?.username ?? readUsernameFromToken(),
    email: profileFromStorage?.email ?? "",
    phone: profileFromStorage?.phone ?? "",
  });
  const [profileMessage, setProfileMessage] = useState("");
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordMessage, setPasswordMessage] = useState("");
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const [security, setSecurity] = useState<SecuritySetting>({
    loginAlert: securityFromStorage?.loginAlert ?? true,
    autoLogoutIdle: securityFromStorage?.autoLogoutIdle ?? true,
    maskSensitiveData: securityFromStorage?.maskSensitiveData ?? true,
  });
  const [securityMessage, setSecurityMessage] = useState("");

  const [notifications, setNotifications] = useState<NotificationSetting>({
    orderAlert: notificationsFromStorage?.orderAlert ?? true,
    inventoryAlert: notificationsFromStorage?.inventoryAlert ?? true,
    weeklyReportEmail: notificationsFromStorage?.weeklyReportEmail ?? false,
  });
  const [notificationMessage, setNotificationMessage] = useState("");

  const [twoFactorStatus, setTwoFactorStatus] = useState<TwoFactorStatus>({
    enabled: false,
    hasPendingSetup: false,
  });
  const [twoFactorSecret, setTwoFactorSecret] = useState("");
  const [twoFactorOtpUri, setTwoFactorOtpUri] = useState("");
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [twoFactorDisablePassword, setTwoFactorDisablePassword] = useState("");
  const [twoFactorMessage, setTwoFactorMessage] = useState("");

  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [sessionsMessage, setSessionsMessage] = useState("");

  const [securityLogs, setSecurityLogs] = useState<SecurityLogItem[]>([]);

  function getAccessToken() {
    return localStorage.getItem("adminmct:token") ?? "";
  }

  async function fetchSessions() {
    const token = getAccessToken();
    if (!token) {
      return;
    }

    try {
      const res = await fetch("/api/account/sessions", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        return;
      }

      const data = await res.json();
      setSessions(Array.isArray(data.items) ? data.items : []);
    } catch {
      // Ignore transient read errors.
    }
  }

  async function fetchSecurityLogs() {
    const token = getAccessToken();
    if (!token) {
      return;
    }

    try {
      const res = await fetch("/api/account/security-logs?limit=30", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        return;
      }

      const data = await res.json();
      setSecurityLogs(Array.isArray(data.items) ? data.items : []);
    } catch {
      // Ignore transient read errors.
    }
  }

  async function fetchTwoFactorStatus() {
    const token = getAccessToken();
    if (!token) {
      return;
    }

    try {
      const res = await fetch("/api/account/2fa/status", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        return;
      }

      const data = await res.json();
      setTwoFactorStatus({
        enabled: Boolean(data.enabled),
        hasPendingSetup: Boolean(data.hasPendingSetup),
      });
    } catch {
      // Ignore transient read errors.
    }
  }

  useEffect(() => {
    let isMounted = true;

    async function loadProfileFromApi() {
      const token = localStorage.getItem("adminmct:token");
      if (!token) {
        return;
      }

      try {
        const res = await fetch("/api/account/profile", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!res.ok) {
          return;
        }

        const data = await res.json();

        if (!isMounted) {
          return;
        }

        setProfile((prev) => ({
          ...prev,
          name: data.name ?? prev.name,
          username: data.username ?? prev.username,
          email: data.email ?? "",
          phone: data.phone ?? "",
        }));

        if (data.name) {
          localStorage.setItem("adminmct:admin-name", data.name);
          onAdminNameChange(data.name);
        }
      } catch {
        // Keep local fallback data if API is temporarily unavailable.
      }
    }

    void loadProfileFromApi();
    void fetchSessions();
    void fetchSecurityLogs();
    void fetchTwoFactorStatus();

    return () => {
      isMounted = false;
    };
  }, [onAdminNameChange]);

  async function handleProfileSave(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!profile.name.trim()) {
      setProfileMessage("Vui lòng nhập họ và tên.");
      return;
    }

    const token = localStorage.getItem("adminmct:token");
    if (!token) {
      setProfileMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    setIsSavingProfile(true);
    setProfileMessage("");

    try {
      const res = await fetch("/api/account/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: profile.name.trim(),
          email: profile.email.trim(),
          phone: profile.phone.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setProfileMessage(data.message ?? "Không thể lưu thông tin tài khoản.");
        setIsSavingProfile(false);
        return;
      }

      const nextProfile = {
        ...profile,
        name: data.name ?? profile.name.trim(),
        username: data.username ?? profile.username,
        email: data.email ?? profile.email,
        phone: data.phone ?? profile.phone,
      };

      setProfile(nextProfile);
      localStorage.setItem("adminmct:admin-name", nextProfile.name);
      localStorage.setItem(
        "adminmct:account-profile",
        JSON.stringify(nextProfile),
      );
      onAdminNameChange(nextProfile.name);
      setProfileMessage("Đã lưu thông tin tài khoản.");
      setIsSavingProfile(false);
    } catch {
      setProfileMessage("Không kết nối được tới máy chủ.");
      setIsSavingProfile(false);
    }
  }

  async function handlePasswordSave(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (
      !passwordForm.currentPassword ||
      !passwordForm.newPassword ||
      !passwordForm.confirmPassword
    ) {
      setPasswordMessage("Vui lòng nhập đầy đủ thông tin mật khẩu.");
      return;
    }

    if (passwordForm.newPassword.length < 8) {
      setPasswordMessage("Mật khẩu mới phải có ít nhất 8 ký tự.");
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setPasswordMessage("Xác nhận mật khẩu mới chưa khớp.");
      return;
    }

    const token = localStorage.getItem("adminmct:token");
    if (!token) {
      setPasswordMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    setIsChangingPassword(true);
    setPasswordMessage("");

    try {
      const res = await fetch("/api/account/password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setPasswordMessage(data.message ?? "Không thể cập nhật mật khẩu.");
        setIsChangingPassword(false);
        return;
      }

      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setPasswordMessage("Đã cập nhật mật khẩu thành công.");
      void fetchSecurityLogs();
      setIsChangingPassword(false);
    } catch {
      setPasswordMessage("Không kết nối được tới máy chủ.");
      setIsChangingPassword(false);
    }
  }

  function handleSecuritySave(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    localStorage.setItem("adminmct:setting-security", JSON.stringify(security));
    setSecurityMessage("Đã lưu cài đặt bảo mật.");
  }

  function handleNotificationSave(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    localStorage.setItem(
      "adminmct:setting-notifications",
      JSON.stringify(notifications),
    );
    setNotificationMessage("Đã lưu cài đặt thông báo.");
  }

  async function handleTwoFactorSetupStart() {
    const token = getAccessToken();
    if (!token) {
      setTwoFactorMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    setTwoFactorMessage("");

    try {
      const res = await fetch("/api/account/2fa/setup", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (!res.ok) {
        setTwoFactorMessage(data.message ?? "Không tạo được thiết lập 2FA.");
        return;
      }

      setTwoFactorSecret(data.secret ?? "");
      setTwoFactorOtpUri(data.otpauthUrl ?? "");
      setTwoFactorMessage(
        "Đã tạo mã bí mật. Mở app Authenticator để thêm tài khoản.",
      );
      setTwoFactorStatus((prev) => ({ ...prev, hasPendingSetup: true }));
    } catch {
      setTwoFactorMessage("Không kết nối được tới máy chủ.");
    }
  }

  async function handleTwoFactorEnable(
    event: React.FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    if (!twoFactorCode.trim()) {
      setTwoFactorMessage("Vui lòng nhập mã xác thực 6 số để kích hoạt 2FA.");
      return;
    }

    const token = getAccessToken();
    if (!token) {
      setTwoFactorMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    try {
      const res = await fetch("/api/account/2fa/enable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ code: twoFactorCode.trim() }),
      });

      const data = await res.json();
      if (!res.ok) {
        setTwoFactorMessage(data.message ?? "Không thể kích hoạt 2FA.");
        return;
      }

      setTwoFactorCode("");
      setTwoFactorSecret("");
      setTwoFactorOtpUri("");
      setTwoFactorMessage("Đã bật xác thực 2 lớp (2FA).");
      setTwoFactorStatus({ enabled: true, hasPendingSetup: false });
      void fetchSecurityLogs();
    } catch {
      setTwoFactorMessage("Không kết nối được tới máy chủ.");
    }
  }

  async function handleTwoFactorDisable(
    event: React.FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    if (!twoFactorDisablePassword) {
      setTwoFactorMessage("Vui lòng nhập mật khẩu hiện tại để tắt 2FA.");
      return;
    }

    const token = getAccessToken();
    if (!token) {
      setTwoFactorMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    try {
      const res = await fetch("/api/account/2fa/disable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword: twoFactorDisablePassword }),
      });

      const data = await res.json();
      if (!res.ok) {
        setTwoFactorMessage(data.message ?? "Không thể tắt 2FA.");
        return;
      }

      setTwoFactorDisablePassword("");
      setTwoFactorStatus({ enabled: false, hasPendingSetup: false });
      setTwoFactorMessage("Đã tắt xác thực 2 lớp.");
      void fetchSecurityLogs();
    } catch {
      setTwoFactorMessage("Không kết nối được tới máy chủ.");
    }
  }

  async function handleRevokeSession(sessionId: string) {
    const token = getAccessToken();
    if (!token) {
      setSessionsMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    try {
      const res = await fetch(`/api/account/sessions/${sessionId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (!res.ok) {
        setSessionsMessage(data.message ?? "Không thể thu hồi phiên.");
        return;
      }

      setSessionsMessage("Đã thu hồi phiên đăng nhập.");
      void fetchSessions();
      void fetchSecurityLogs();
    } catch {
      setSessionsMessage("Không kết nối được tới máy chủ.");
    }
  }

  async function handleRevokeOtherSessions() {
    const token = getAccessToken();
    if (!token) {
      setSessionsMessage("Bạn chưa đăng nhập hợp lệ. Vui lòng đăng nhập lại.");
      return;
    }

    try {
      const res = await fetch("/api/account/sessions/revoke-others", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (!res.ok) {
        setSessionsMessage(data.message ?? "Không thể thu hồi các phiên khác.");
        return;
      }

      setSessionsMessage("Đã thu hồi tất cả phiên khác.");
      void fetchSessions();
      void fetchSecurityLogs();
    } catch {
      setSessionsMessage("Không kết nối được tới máy chủ.");
    }
  }

  const isTwoFactorReadyToEnable =
    twoFactorStatus.hasPendingSetup || twoFactorSecret;

  return (
    <section className="setting-page">
      <header className="topbar setting-topbar">
        <div>
          <p className="eyebrow">Tài khoản</p>
          <h1>Cài đặt</h1>
        </div>
      </header>

      <section className="setting-grid">
        <article className="panel">
          <div className="panel-head setting-head">
            <h2>Tài khoản</h2>
          </div>

          <form className="setting-form" onSubmit={handleProfileSave}>
            <h3 className="setting-subtitle">Thông tin tài khoản đăng nhập</h3>

            <label className="setting-field">
              <span>Họ và tên</span>
              <input
                type="text"
                value={profile.name}
                onChange={(event) =>
                  setProfile((prev) => ({ ...prev, name: event.target.value }))
                }
                placeholder="Nhập họ và tên"
              />
            </label>

            <label className="setting-field">
              <span>Tên đăng nhập</span>
              <input type="text" value={profile.username} readOnly />
            </label>

            <label className="setting-field">
              <span>Email liên hệ</span>
              <input
                type="email"
                value={profile.email}
                onChange={(event) =>
                  setProfile((prev) => ({ ...prev, email: event.target.value }))
                }
                placeholder="admin@company.com"
              />
            </label>

            <label className="setting-field">
              <span>Số điện thoại</span>
              <input
                type="tel"
                value={profile.phone}
                onChange={(event) =>
                  setProfile((prev) => ({ ...prev, phone: event.target.value }))
                }
                placeholder="090..."
              />
            </label>

            <div className="setting-actions">
              <button
                className="primary-btn"
                type="submit"
                disabled={isSavingProfile}
              >
                {isSavingProfile ? "Đang lưu..." : "Lưu thông tin"}
              </button>
            </div>

            {profileMessage ? (
              <p className="setting-message">{profileMessage}</p>
            ) : null}
          </form>

          <div className="setting-divider"></div>

          <form className="setting-form" onSubmit={handlePasswordSave}>
            <h3 className="setting-subtitle">Đổi mật khẩu</h3>

            <label className="setting-field">
              <span>Mật khẩu hiện tại</span>
              <input
                type="password"
                value={passwordForm.currentPassword}
                onChange={(event) =>
                  setPasswordForm((prev) => ({
                    ...prev,
                    currentPassword: event.target.value,
                  }))
                }
                placeholder="Nhập mật khẩu hiện tại"
              />
            </label>

            <label className="setting-field">
              <span>Mật khẩu mới</span>
              <input
                type="password"
                value={passwordForm.newPassword}
                onChange={(event) =>
                  setPasswordForm((prev) => ({
                    ...prev,
                    newPassword: event.target.value,
                  }))
                }
                placeholder="Nhập mật khẩu mới"
              />
            </label>

            <label className="setting-field">
              <span>Nhập lại mật khẩu mới</span>
              <input
                type="password"
                value={passwordForm.confirmPassword}
                onChange={(event) =>
                  setPasswordForm((prev) => ({
                    ...prev,
                    confirmPassword: event.target.value,
                  }))
                }
                placeholder="Xác nhận mật khẩu mới"
              />
            </label>

            <div className="setting-actions">
              <button
                className="primary-btn"
                type="submit"
                disabled={isChangingPassword}
              >
                {isChangingPassword ? "Đang cập nhật..." : "Cập nhật mật khẩu"}
              </button>
            </div>

            {passwordMessage ? (
              <p className="setting-message">{passwordMessage}</p>
            ) : null}
          </form>
        </article>

        <article className="panel">
          <div className="panel-head setting-head">
            <h2>Bảo mật</h2>
          </div>

          <form className="setting-form" onSubmit={handleSecuritySave}>
            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={security.loginAlert}
                onChange={(event) =>
                  setSecurity((prev) => ({
                    ...prev,
                    loginAlert: event.target.checked,
                  }))
                }
              />
              <span>Gửi cảnh báo khi có đăng nhập mới</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={security.autoLogoutIdle}
                onChange={(event) =>
                  setSecurity((prev) => ({
                    ...prev,
                    autoLogoutIdle: event.target.checked,
                  }))
                }
              />
              <span>Tự đăng xuất khi không hoạt động 30 phút</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={security.maskSensitiveData}
                onChange={(event) =>
                  setSecurity((prev) => ({
                    ...prev,
                    maskSensitiveData: event.target.checked,
                  }))
                }
              />
              <span>Ẩn dữ liệu nhạy cảm trong giao diện quản trị</span>
            </label>

            <div className="setting-actions">
              <button className="primary-btn" type="submit">
                Lưu bảo mật
              </button>
            </div>

            {securityMessage ? (
              <p className="setting-message">{securityMessage}</p>
            ) : null}
          </form>

          <div className="setting-divider"></div>

          <div className="setting-form">
            <h3 className="setting-subtitle">Xác thực 2 lớp (2FA)</h3>

            <p className="setting-hint">
              Trạng thái: {twoFactorStatus.enabled ? "Đã bật" : "Chưa bật"}
            </p>

            {twoFactorStatus.enabled ? (
              <form className="setting-form" onSubmit={handleTwoFactorDisable}>
                <label className="setting-field">
                  <span>Nhập mật khẩu hiện tại để tắt 2FA</span>
                  <input
                    type="password"
                    value={twoFactorDisablePassword}
                    onChange={(event) =>
                      setTwoFactorDisablePassword(event.target.value)
                    }
                    placeholder="Mật khẩu hiện tại"
                  />
                </label>

                <div className="setting-actions">
                  <button className="ghost-btn" type="submit">
                    Tắt 2FA
                  </button>
                </div>
              </form>
            ) : (
              <>
                <div className="setting-actions">
                  <button
                    className="ghost-btn"
                    type="button"
                    onClick={handleTwoFactorSetupStart}
                  >
                    {isTwoFactorReadyToEnable
                      ? "Tạo lại mã 2FA"
                      : "Thiết lập 2FA"}
                  </button>
                </div>

                {isTwoFactorReadyToEnable ? (
                  <form
                    className="setting-form"
                    onSubmit={handleTwoFactorEnable}
                  >
                    {twoFactorSecret ? (
                      <p className="setting-hint">
                        Secret key: <strong>{twoFactorSecret}</strong>
                      </p>
                    ) : null}

                    {twoFactorOtpUri ? (
                      <p className="setting-hint setting-wrap">
                        {twoFactorOtpUri}
                      </p>
                    ) : null}

                    <label className="setting-field">
                      <span>Nhập mã 6 số từ Google Authenticator</span>
                      <input
                        type="text"
                        value={twoFactorCode}
                        onChange={(event) =>
                          setTwoFactorCode(event.target.value)
                        }
                        inputMode="numeric"
                        placeholder="123456"
                      />
                    </label>

                    <div className="setting-actions">
                      <button className="primary-btn" type="submit">
                        Xác nhận bật 2FA
                      </button>
                    </div>
                  </form>
                ) : null}
              </>
            )}

            {twoFactorMessage ? (
              <p className="setting-message">{twoFactorMessage}</p>
            ) : null}
          </div>
        </article>

        <article className="panel">
          <div className="panel-head setting-head">
            <h2>Thông báo quản trị</h2>
          </div>

          <form className="setting-form" onSubmit={handleNotificationSave}>
            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.orderAlert}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    orderAlert: event.target.checked,
                  }))
                }
              />
              <span>Thông báo khi có đơn hàng mới</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.inventoryAlert}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    inventoryAlert: event.target.checked,
                  }))
                }
              />
              <span>Thông báo khi tồn kho thấp</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.weeklyReportEmail}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    weeklyReportEmail: event.target.checked,
                  }))
                }
              />
              <span>Nhận email báo cáo tổng hợp hàng tuần</span>
            </label>

            <div className="setting-actions">
              <button className="primary-btn" type="submit">
                Lưu thông báo
              </button>
            </div>

            {notificationMessage ? (
              <p className="setting-message">{notificationMessage}</p>
            ) : null}
          </form>
        </article>

        <article className="panel setting-panel-full">
          <div className="panel-head setting-head">
            <h2>Hệ thống & phiên làm việc</h2>
            <button
              className="ghost-btn"
              type="button"
              onClick={handleRevokeOtherSessions}
            >
              Thu hồi phiên khác
            </button>
          </div>

          <div className="setting-system-grid">
            <div>
              <p className="setting-system-label">Tài khoản hiện tại</p>
              <strong>{profile.username}</strong>
            </div>

            <div>
              <p className="setting-system-label">Vai trò</p>
              <strong>Admin</strong>
            </div>

            <div>
              <p className="setting-system-label">Token đăng nhập</p>
              <strong>
                {localStorage.getItem("adminmct:token")
                  ? "Đang hoạt động"
                  : "Không có"}
              </strong>
            </div>

            <div>
              <p className="setting-system-label">API Endpoint</p>
              <strong>/api</strong>
            </div>
          </div>

          <div className="setting-divider"></div>

          <div className="setting-session-list">
            {sessions.map((session) => (
              <div key={session.id} className="setting-session-item">
                <div>
                  <p className="setting-session-title">
                    {session.isCurrent ? "Phiên hiện tại" : "Phiên đăng nhập"}
                  </p>
                  <p className="setting-session-meta">
                    IP: {session.ipAddress || "N/A"}
                  </p>
                  <p className="setting-session-meta">
                    Thiết bị: {session.userAgent || "N/A"}
                  </p>
                  <p className="setting-session-meta">
                    Tạo lúc:{" "}
                    {new Date(session.createdAt).toLocaleString("vi-VN")}
                  </p>
                  <p className="setting-session-meta">
                    Hoạt động gần nhất:{" "}
                    {new Date(session.lastSeenAt).toLocaleString("vi-VN")}
                  </p>
                </div>

                {!session.isCurrent ? (
                  <button
                    className="ghost-btn"
                    type="button"
                    onClick={() => void handleRevokeSession(session.id)}
                  >
                    Thu hồi
                  </button>
                ) : null}
              </div>
            ))}
          </div>

          {sessionsMessage ? (
            <p className="setting-message">{sessionsMessage}</p>
          ) : null}
        </article>

        <article className="panel setting-panel-full">
          <div className="panel-head setting-head">
            <h2>Nhật ký bảo mật</h2>
          </div>

          <div className="setting-log-list">
            {securityLogs.map((log) => (
              <div key={log.id} className="setting-log-item">
                <p className="setting-log-title">{log.action}</p>
                <p className="setting-log-meta">
                  {new Date(log.createdAt).toLocaleString("vi-VN")} - IP:{" "}
                  {log.ipAddress || "N/A"}
                </p>
                <p className="setting-log-meta">
                  Thiết bị: {log.userAgent || "N/A"}
                </p>
              </div>
            ))}
          </div>
        </article>
      </section>
    </section>
  );
}

export default Setting;
