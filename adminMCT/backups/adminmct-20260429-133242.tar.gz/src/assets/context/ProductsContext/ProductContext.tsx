import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

export type BrandItem = {
  id: number;
  name: string;
  is_active: 0 | 1;
  created_at: string;
};

export type ProductItem = {
  id: number;
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

export type BrandPayload = {
  name: string;
  is_active: 0 | 1;
};

export type ProductPayload = {
  brand_id: number;
  name: string;
  link: string;
  is_active: 0 | 1;
};

type ApiResult<T> = {
  ok: boolean;
  data?: T;
  message?: string;
};

type ProductContextValue = {
  brandItems: BrandItem[];
  productItems: ProductItem[];
  isLoadingProducts: boolean;
  productsMessage: string;
  refreshProductData: () => Promise<void>;
  createBrandItem: (payload: BrandPayload) => Promise<ApiResult<BrandItem>>;
  updateBrandItem: (
    id: number,
    payload: BrandPayload,
  ) => Promise<ApiResult<BrandItem>>;
  deleteBrandItem: (id: number) => Promise<ApiResult<null>>;
  createProductItem: (
    payload: ProductPayload,
  ) => Promise<ApiResult<ProductItem>>;
  updateProductItem: (
    id: number,
    payload: ProductPayload,
  ) => Promise<ApiResult<ProductItem>>;
  deleteProductItem: (id: number) => Promise<ApiResult<null>>;
};

type ProductProviderProps = {
  children: ReactNode;
};

type ProductRow = {
  id: number;
  brand_id: number | null;
  name: string;
  link: string;
  is_active: 0 | 1;
  created_at: string;
};

const PRODUCT_API_CANDIDATES = [
  import.meta.env.VITE_PRODUCTS_API_ENDPOINT || "",
  "/api/product_items",
  "/api/product-items",
  "/api/products",
].filter(Boolean);

const ProductContext = createContext<ProductContextValue>({
  brandItems: [],
  productItems: [],
  isLoadingProducts: false,
  productsMessage: "",
  refreshProductData: async () => {},
  createBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  updateBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  deleteBrandItem: async () => ({ ok: false, message: "Not implemented." }),
  createProductItem: async () => ({ ok: false, message: "Not implemented." }),
  updateProductItem: async () => ({ ok: false, message: "Not implemented." }),
  deleteProductItem: async () => ({ ok: false, message: "Not implemented." }),
});

let resolvedProductEndpoint: string | null = null;

function getNowDateTime(): string {
  return new Date().toISOString().slice(0, 19).replace("T", " ");
}

function getAuthToken(): string {
  return localStorage.getItem("adminmct:token") ?? "";
}

function createSlug(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

function normalizeProductRow(raw: unknown): ProductRow {
  const item = (raw ?? {}) as Record<string, unknown>;
  const rawBrandId =
    item.brand_id ?? item.brandId ?? item.category_id ?? item.categoryId;
  const numericBrand = Number(rawBrandId);

  return {
    id: Number(item.id) || 0,
    brand_id:
      Number.isFinite(numericBrand) && numericBrand > 0 ? numericBrand : null,
    name: String(item.name ?? item.title ?? ""),
    link: String(item.link ?? item.url ?? ""),
    is_active: Number(item.is_active) === 0 ? 0 : 1,
    created_at: String(item.created_at ?? item.createdAt ?? getNowDateTime()),
  };
}

function toBrandItem(row: ProductRow): BrandItem {
  return {
    id: row.id,
    name: row.name,
    is_active: row.is_active,
    created_at: row.created_at,
  };
}

function toProductItem(row: ProductRow): ProductItem {
  return {
    id: row.id,
    brand_id: row.brand_id ?? 0,
    name: row.name,
    link: row.link,
    is_active: row.is_active,
    created_at: row.created_at,
  };
}

async function readResponseMessage(
  res: Response,
  fallback: string,
): Promise<string> {
  try {
    const data = (await res.json()) as { message?: string };
    return data.message ?? fallback;
  } catch {
    return fallback;
  }
}

async function resolveProductEndpoint(token: string): Promise<string> {
  if (resolvedProductEndpoint) {
    return resolvedProductEndpoint;
  }

  for (const endpoint of PRODUCT_API_CANDIDATES) {
    try {
      const res = await fetch(endpoint, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status !== 404) {
        resolvedProductEndpoint = endpoint;
        return endpoint;
      }
    } catch {
      // Try next endpoint.
    }
  }

  resolvedProductEndpoint = PRODUCT_API_CANDIDATES[0] || "/api/product_items";
  return resolvedProductEndpoint || "/api/product_items";
}

async function readListPayload(res: Response): Promise<ProductRow[]> {
  const payload = (await res.json()) as
    | ProductRow[]
    | {
        items?: ProductRow[];
        data?: ProductRow[];
        rows?: ProductRow[];
        list?: ProductRow[];
        products?: ProductRow[];
        product_items?: ProductRow[];
      };

  const list = Array.isArray(payload)
    ? payload
    : Array.isArray(payload.items)
      ? payload.items
      : Array.isArray(payload.data)
        ? payload.data
        : Array.isArray(payload.rows)
          ? payload.rows
          : Array.isArray(payload.list)
            ? payload.list
            : Array.isArray(payload.products)
              ? payload.products
              : Array.isArray(payload.product_items)
                ? payload.product_items
                : [];

  return list
    .map((item) => normalizeProductRow(item))
    .filter((item) => item.id > 0)
    .sort((a, b) => a.id - b.id);
}

async function loadRowsFromApi(): Promise<ApiResult<ProductRow[]>> {
  const token = getAuthToken();
  if (!token) {
    return { ok: false, message: "Thiếu token đăng nhập." };
  }

  try {
    const endpoint = await resolveProductEndpoint(token);
    const res = await fetch(endpoint, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      return {
        ok: false,
        message: await readResponseMessage(
          res,
          "Không tải được dữ liệu product_items.",
        ),
      };
    }

    return { ok: true, data: await readListPayload(res) };
  } catch {
    return { ok: false, message: "Không kết nối được API sản phẩm." };
  }
}

async function requestProductMutation<T>(
  endpoint: string,
  method: "POST" | "PUT" | "DELETE",
  body?: unknown,
): Promise<ApiResult<T>> {
  const token = getAuthToken();
  if (!token) {
    return { ok: false, message: "Thiếu token đăng nhập." };
  }

  try {
    const res = await fetch(endpoint, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      return {
        ok: false,
        message: await readResponseMessage(res, "Thao tác API thất bại."),
      };
    }

    if (method === "DELETE") {
      return { ok: true, data: null as T };
    }

    const data = (await res.json()) as T | { item?: T; data?: T };
    const value =
      typeof data === "object" &&
      data !== null &&
      ("item" in data || "data" in data)
        ? (((data as { item?: T }).item ?? (data as { data?: T }).data) as T)
        : (data as T);

    return { ok: true, data: value };
  } catch {
    return { ok: false, message: "Không kết nối được API." };
  }
}

export function ProductProvider({ children }: ProductProviderProps) {
  const [rows, setRows] = useState<ProductRow[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [productsMessage, setProductsMessage] = useState("");

  const brandItems = useMemo(
    () => rows.filter((row) => row.brand_id === null).map(toBrandItem),
    [rows],
  );

  const productItems = useMemo(
    () =>
      rows
        .filter((row) => row.brand_id !== null)
        .map(toProductItem)
        .sort((a, b) => b.id - a.id),
    [rows],
  );

  async function refreshProductData() {
    setIsLoadingProducts(true);
    const result = await loadRowsFromApi();

    if (!result.ok || !result.data) {
      setRows([]);
      setProductsMessage(result.message ?? "Không tải được product_items.");
      setIsLoadingProducts(false);
      return;
    }

    setRows(result.data);
    setProductsMessage("");
    setIsLoadingProducts(false);
  }

  async function createBrandItem(payload: BrandPayload) {
    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<ProductRow>(endpoint, "POST", {
      brand_id: null,
      name: payload.name.trim(),
      link: `/product/${createSlug(payload.name)}`,
      is_active: payload.is_active,
    });

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data
          ? toBrandItem(normalizeProductRow(result.data))
          : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function updateBrandItem(id: number, payload: BrandPayload) {
    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<ProductRow>(
      `${endpoint}/${id}`,
      "PUT",
      {
        brand_id: null,
        name: payload.name.trim(),
        link: `/product/${createSlug(payload.name)}`,
        is_active: payload.is_active,
      },
    );

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data
          ? toBrandItem(normalizeProductRow(result.data))
          : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function deleteBrandItem(id: number) {
    if (rows.some((row) => row.brand_id === id)) {
      return {
        ok: false,
        message:
          "Nhãn hiệu đang có sản phẩm, vui lòng xóa/chuyển sản phẩm trước.",
      };
    }

    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<null>(
      `${endpoint}/${id}`,
      "DELETE",
    );

    if (result.ok) {
      await refreshProductData();
    }

    return result;
  }

  async function createProductItem(payload: ProductPayload) {
    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<ProductRow>(endpoint, "POST", {
      brand_id: payload.brand_id,
      name: payload.name.trim(),
      link: payload.link.trim(),
      is_active: payload.is_active,
    });

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data
          ? toProductItem(normalizeProductRow(result.data))
          : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function updateProductItem(id: number, payload: ProductPayload) {
    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<ProductRow>(
      `${endpoint}/${id}`,
      "PUT",
      {
        brand_id: payload.brand_id,
        name: payload.name.trim(),
        link: payload.link.trim(),
        is_active: payload.is_active,
      },
    );

    if (result.ok) {
      await refreshProductData();
      return {
        ok: true,
        data: result.data
          ? toProductItem(normalizeProductRow(result.data))
          : undefined,
      };
    }

    return { ok: false, message: result.message };
  }

  async function deleteProductItem(id: number) {
    const token = getAuthToken();
    const endpoint = await resolveProductEndpoint(token);
    const result = await requestProductMutation<null>(
      `${endpoint}/${id}`,
      "DELETE",
    );

    if (result.ok) {
      await refreshProductData();
    }

    return result;
  }

  useEffect(() => {
    void refreshProductData();
  }, []);

  const value = useMemo(
    () => ({
      brandItems,
      productItems,
      isLoadingProducts,
      productsMessage,
      refreshProductData,
      createBrandItem,
      updateBrandItem,
      deleteBrandItem,
      createProductItem,
      updateProductItem,
      deleteProductItem,
    }),
    [brandItems, isLoadingProducts, productItems, productsMessage],
  );

  return (
    <ProductContext.Provider value={value}>{children}</ProductContext.Provider>
  );
}

export function useProductContext(): ProductContextValue {
  return useContext(ProductContext);
}
