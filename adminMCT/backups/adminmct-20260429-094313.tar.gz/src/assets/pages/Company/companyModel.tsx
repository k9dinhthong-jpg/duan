export type TabKey =
  | "basic"
  | "legal"
  | "social"
  | "media"
  | "seo"
  | "system";

export type CustomField = {
  id: string;
  key: string;
  label: string;
  value: string;
};

export type CompanyInfo = {
  id: number;
  short_name: string;
  full_name: string;
  slogan: string;
  about: string;
  tax_code: string;
  business_license: string;
  legal_representative: string;
  established_year: number;
  phone: string;
  hotline: string;
  email: string;
  contact_email: string;
  website: string;
  address: string;
  map_address: string;
  google_map_embed: string;
  facebook: string;
  zalo: string;
  whatsapp: string;
  telegram: string;
  tiktok: string;
  instagram: string;
  youtube: string;
  wechat: string;
  logo_url: string;
  intro_image: string;
  og_image: string;
  favicon_url: string;
  meta_title: string;
  meta_description: string;
  meta_keywords: string;
  copyright_text: string;
  working_hours: string;
  is_active: 0 | 1;
  created_at: string;
  updated_at: string;
  custom_fields: CustomField[];
};

export type UpdateCompanyField = <K extends keyof CompanyInfo>(
  field: K,
  value: CompanyInfo[K],
) => void;

export type UpdateCustomField = (
  id: string,
  field: keyof Omit<CustomField, "id">,
  value: string,
) => void;

export const COMPANY_STORAGE_KEY = "adminmct:company-info";

export const defaultCompanyInfo: CompanyInfo = {
  id: 1,
  short_name: "MAY CONG TRINH NHAP KHAU",
  full_name: "Cong Ty Xuat Nhap Khau May Cong Trinh",
  slogan: "May Cong Trinh Chat Luong Cao",
  about:
    "Chuyen cung cap may cong trinh nhap khau chinh hang, bao gom may xuc, may dao, may ui cac thuong hieu KOBELCO, KOMATSU, HITACHI. Cam ket chat luong va dich vu hau mai tan tam.",
  tax_code: "Dang cap nhat",
  business_license: "",
  legal_representative: "",
  established_year: 2020,
  phone: "0966121686",
  hotline: "0966121686",
  email: "k9dinhthong@gmail.com",
  contact_email: "k9dinhthong@gmail.com",
  website: "https://maycongtrinhnhapkhau.com.vn",
  address: "So 168 - Khu 4 - Xa Te Lo",
  map_address: "https://www.google.com/maps",
  google_map_embed: "",
  facebook: "https://www.facebook.com/",
  zalo: "https://zalo.me/0966121686",
  whatsapp: "",
  telegram: "https://t.me/sugar88_vr",
  tiktok: "https://www.tiktok.com/",
  instagram: "#",
  youtube: "#",
  wechat: "https://ehsccjufbaehvfo",
  logo_url: "/img/Logo/Logo.png",
  intro_image: "/img/IntroCompany/Company.png",
  og_image: "/img/Logo/Logo.png",
  favicon_url: "/img/Logo/Favicon.png",
  meta_title: "KOBELCO - KOMATSU - HITACHI",
  meta_description:
    "Chuyen mua ban may cong trinh nhap khau, may xuc, may dao, may ui, phu tung va dich vu lien quan.",
  meta_keywords:
    "may cong trinh, may xuc, may dao, kobelco, komatsu, hitachi, may cong trinh nhap khau",
  copyright_text:
    "(c) 2026 Cong Ty Xuat Nhap Khau May Cong Trinh. All rights reserved.",
  working_hours: "Thu 2 - Chu nhat: 08:00 - 18:00",
  is_active: 1,
  created_at: "2026-04-27 14:37:16",
  updated_at: "2026-04-28 10:58:03",
  custom_fields: [],
};

export function loadCompanyFromDatabase(): CompanyInfo {
  const raw = localStorage.getItem(COMPANY_STORAGE_KEY);
  if (!raw) {
    return defaultCompanyInfo;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<CompanyInfo>;
    return {
      ...defaultCompanyInfo,
      ...parsed,
      custom_fields: Array.isArray(parsed.custom_fields)
        ? parsed.custom_fields
        : defaultCompanyInfo.custom_fields,
    };
  } catch {
    return defaultCompanyInfo;
  }
}

export function saveCompanyToDatabase(company: CompanyInfo): void {
  localStorage.setItem(COMPANY_STORAGE_KEY, JSON.stringify(company));
}

export function createCustomField(): CustomField {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    key: "",
    label: "",
    value: "",
  };
}