import type {
  CompanyInfo,
  UpdateCompanyField,
  UpdateCustomField,
} from "../companyModel";

type SystemProps = {
  form: CompanyInfo;
  updateField: UpdateCompanyField;
  addCustomField: () => void;
  updateCustomField: UpdateCustomField;
  removeCustomField: (id: string) => void;
};

function System({
  form,
  updateField,
  addCustomField,
  updateCustomField,
  removeCustomField,
}: SystemProps) {
  return (
    <div className="co-card">
      <div className="co-card-head">
        <h2>He thong</h2>
        <p>Trang thai hoat dong, thong tin luu tru va truong tuy chinh.</p>
      </div>
      <div className="co-grid">
        <div className="co-field">
          <label htmlFor="is_active">Trang thai website</label>
          <select
            id="is_active"
            value={String(form.is_active)}
            onChange={(e) =>
              updateField("is_active", Number(e.target.value) as 0 | 1)
            }
          >
            <option value="1">Hoat dong (Online)</option>
            <option value="0">Tam dung (Maintenance)</option>
          </select>
        </div>
        <div className="co-field">
          <label>Ngay tao</label>
          <input type="text" value={form.created_at} readOnly />
        </div>
        <div className="co-field">
          <label>Cap nhat lan cuoi</label>
          <input type="text" value={form.updated_at} readOnly />
        </div>
      </div>

      <div className="co-divider">
        <span>Truong mo rong tuy chinh</span>
      </div>

      <div className="co-custom-fields">
        {form.custom_fields.length === 0 ? (
          <p className="co-empty">
            Chua co truong nao. Nhan "+ Them truong" de bat dau.
          </p>
        ) : null}
        {form.custom_fields.map((customField) => (
          <div className="co-custom-row" key={customField.id}>
            <div className="co-field">
              <label>Ten hien thi</label>
              <input
                type="text"
                value={customField.label}
                onChange={(e) =>
                  updateCustomField(customField.id, "label", e.target.value)
                }
              />
            </div>
            <div className="co-field">
              <label>Khoa (key)</label>
              <input
                type="text"
                value={customField.key}
                onChange={(e) =>
                  updateCustomField(customField.id, "key", e.target.value)
                }
              />
            </div>
            <div className="co-field">
              <label>Gia tri</label>
              <input
                type="text"
                value={customField.value}
                onChange={(e) =>
                  updateCustomField(customField.id, "value", e.target.value)
                }
              />
            </div>
            <button
              type="button"
              className="co-delete-btn"
              onClick={() => removeCustomField(customField.id)}
              title="Xoa truong"
            >
              X
            </button>
          </div>
        ))}
        <button
          type="button"
          className="ghost-btn co-add-btn"
          onClick={addCustomField}
        >
          + Them truong
        </button>
      </div>
    </div>
  );
}

export default System;
