import type { CompanyInfo, UpdateCompanyField } from "../companyModel";

type SeoProps = {
  form: CompanyInfo;
  updateField: UpdateCompanyField;
};

function Seo({ form, updateField }: SeoProps) {
  return (
    <div className="co-card">
      <div className="co-card-head">
        <h2>SEO</h2>
        <p>Thong tin toi uu tim kiem cho trang chu va trang mac dinh.</p>
      </div>
      <div className="co-grid">
        <div className="co-field co-field--wide">
          <label htmlFor="meta_title">Tieu de SEO</label>
          <input
            id="meta_title"
            type="text"
            value={form.meta_title}
            onChange={(e) => updateField("meta_title", e.target.value)}
          />
          <span className="co-hint">
            Nen tu 50-60 ky tu. Hien tai:{" "}
            <strong>{form.meta_title.length}</strong> ky tu.
          </span>
        </div>
        <div className="co-field co-field--wide">
          <label htmlFor="meta_description">Mo ta SEO</label>
          <textarea
            id="meta_description"
            rows={3}
            value={form.meta_description}
            onChange={(e) => updateField("meta_description", e.target.value)}
          />
          <span className="co-hint">
            Nen tu 120-160 ky tu. Hien tai:{" "}
            <strong>{form.meta_description.length}</strong> ky tu.
          </span>
        </div>
        <div className="co-field co-field--wide">
          <label htmlFor="meta_keywords">Tu khoa SEO</label>
          <textarea
            id="meta_keywords"
            rows={3}
            value={form.meta_keywords}
            onChange={(e) => updateField("meta_keywords", e.target.value)}
          />
        </div>
      </div>
    </div>
  );
}

export default Seo;
