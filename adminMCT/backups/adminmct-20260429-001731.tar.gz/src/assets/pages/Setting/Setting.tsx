import { useMemo, useState } from "react";
import "./Setting.css";
import AccountSetting from "./AccountSetting/AccountSetting";
import SecuritySetting from "./SecuritySetting/SecuritySetting";
import LoginLogSetting from "./LoginLogSetting/LoginLogSetting";
import SystemSetting from "./SystemSetting/SystemSetting";

type SettingProps = {
  onAdminNameChange: (name: string) => void;
};

type NotificationSetting = {
  orderAlert: boolean;
  inventoryAlert: boolean;
  weeklyReportEmail: boolean;
};

function readUsernameFromToken(): string {
  const token = localStorage.getItem("adminmct:token");
  if (!token) {
    return "admin";
  }

  try {
    const payload = token.split(".")[1];
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const json = JSON.parse(window.atob(normalized));
    return typeof json.username === "string" ? json.username : "admin";
  } catch {
    return "admin";
  }
}

function readObjectFromStorage<T>(key: string): Partial<T> | null {
  const raw = localStorage.getItem(key);

  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw) as Partial<T>;
  } catch {
    return null;
  }
}

function Setting({ onAdminNameChange }: SettingProps) {
  const notificationsFromStorage = useMemo(
    () =>
      readObjectFromStorage<NotificationSetting>(
        "adminmct:setting-notifications",
      ),
    [],
  );

  const [notifications, setNotifications] = useState<NotificationSetting>({
    orderAlert: notificationsFromStorage?.orderAlert ?? true,
    inventoryAlert: notificationsFromStorage?.inventoryAlert ?? true,
    weeklyReportEmail: notificationsFromStorage?.weeklyReportEmail ?? false,
  });
  const [notificationMessage, setNotificationMessage] = useState("");

  const [currentUsername, setCurrentUsername] = useState(() =>
    readUsernameFromToken(),
  );
  const [sessionRefreshKey, setSessionRefreshKey] = useState(0);
  const [logRefreshKey, setLogRefreshKey] = useState(0);

  function handleNotificationSave(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    localStorage.setItem(
      "adminmct:setting-notifications",
      JSON.stringify(notifications),
    );
    setNotificationMessage("Đã lưu cài đặt thông báo.");
  }

  return (
    <section className="setting-page">
      <header className="topbar setting-topbar">
        <div>
          <p className="eyebrow">Tài khoản</p>
          <h1>Cài đặt</h1>
        </div>
      </header>

      <section className="setting-grid">
        <AccountSetting
          onAdminNameChange={onAdminNameChange}
          onUsernameChange={setCurrentUsername}
          onPasswordChanged={() => {
            setLogRefreshKey((prev) => prev + 1);
            setSessionRefreshKey((prev) => prev + 1);
          }}
        />

        <SecuritySetting
          onSecurityChanged={() => {
            setLogRefreshKey((prev) => prev + 1);
          }}
        />

        <article className="panel">
          <div className="panel-head setting-head">
            <h2>Thông báo quản trị</h2>
          </div>

          <form className="setting-form" onSubmit={handleNotificationSave}>
            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.orderAlert}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    orderAlert: event.target.checked,
                  }))
                }
              />
              <span>Thông báo khi có đơn hàng mới</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.inventoryAlert}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    inventoryAlert: event.target.checked,
                  }))
                }
              />
              <span>Thông báo khi tồn kho thấp</span>
            </label>

            <label className="setting-toggle">
              <input
                type="checkbox"
                checked={notifications.weeklyReportEmail}
                onChange={(event) =>
                  setNotifications((prev) => ({
                    ...prev,
                    weeklyReportEmail: event.target.checked,
                  }))
                }
              />
              <span>Nhận email báo cáo tổng hợp hàng tuần</span>
            </label>

            <div className="setting-actions">
              <button className="primary-btn" type="submit">
                Lưu thông báo
              </button>
            </div>

            {notificationMessage ? (
              <p className="setting-message">{notificationMessage}</p>
            ) : null}
          </form>
        </article>

        <SystemSetting
          currentUsername={currentUsername}
          refreshKey={sessionRefreshKey}
          onSessionsChanged={() => {
            setLogRefreshKey((prev) => prev + 1);
          }}
        />

        <LoginLogSetting refreshKey={logRefreshKey} />
      </section>
    </section>
  );
}

export default Setting;
